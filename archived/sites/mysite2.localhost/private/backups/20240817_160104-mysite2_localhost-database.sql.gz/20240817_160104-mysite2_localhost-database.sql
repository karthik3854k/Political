-- begin frappe metadata
-- [frappe]
-- version = 16.0.0-dev
-- branch = develop
-- end frappe metadata
-- 
/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.18-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: _70ae88e076d8a1a8
-- ------------------------------------------------------
-- Server version	10.6.18-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__Auth`
--

DROP TABLE IF EXISTS `__Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__Auth` (
  `doctype` varchar(140) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fieldname` varchar(140) NOT NULL,
  `password` text NOT NULL,
  `encrypted` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`doctype`,`name`,`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__Auth`
--

LOCK TABLES `__Auth` WRITE;
/*!40000 ALTER TABLE `__Auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `__Auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__UserSettings`
--

DROP TABLE IF EXISTS `__UserSettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__UserSettings` (
  `user` varchar(180) NOT NULL,
  `doctype` varchar(180) NOT NULL,
  `data` text DEFAULT NULL,
  UNIQUE KEY `user` (`user`,`doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__UserSettings`
--

LOCK TABLES `__UserSettings` WRITE;
/*!40000 ALTER TABLE `__UserSettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `__UserSettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__global_search`
--

DROP TABLE IF EXISTS `__global_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__global_search` (
  `doctype` varchar(100) DEFAULT NULL,
  `name` varchar(140) DEFAULT NULL,
  `title` varchar(140) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `route` varchar(140) DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  UNIQUE KEY `doctype_name` (`doctype`,`name`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__global_search`
--

LOCK TABLES `__global_search` WRITE;
/*!40000 ALTER TABLE `__global_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `__global_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabActivity Log`
--

DROP TABLE IF EXISTS `tabActivity Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabActivity Log` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `subject` text DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `communication_date` datetime(6) DEFAULT NULL,
  `ip_address` varchar(140) DEFAULT NULL,
  `operation` varchar(140) DEFAULT NULL,
  `status` varchar(140) DEFAULT NULL,
  `reference_doctype` varchar(140) DEFAULT NULL,
  `reference_name` varchar(140) DEFAULT NULL,
  `reference_owner` varchar(140) DEFAULT NULL,
  `timeline_doctype` varchar(140) DEFAULT NULL,
  `timeline_name` varchar(140) DEFAULT NULL,
  `link_doctype` varchar(140) DEFAULT NULL,
  `link_name` varchar(140) DEFAULT NULL,
  `user` varchar(140) DEFAULT NULL,
  `full_name` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  `_seen` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`),
  KEY `reference_doctype_reference_name_index` (`reference_doctype`,`reference_name`),
  KEY `timeline_doctype_timeline_name_index` (`timeline_doctype`,`timeline_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabActivity Log`
--

LOCK TABLES `tabActivity Log` WRITE;
/*!40000 ALTER TABLE `tabActivity Log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabActivity Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabClient Script`
--

DROP TABLE IF EXISTS `tabClient Script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabClient Script` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `dt` varchar(140) DEFAULT NULL,
  `view` varchar(140) DEFAULT 'Form',
  `module` varchar(140) DEFAULT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT 0,
  `script` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabClient Script`
--

LOCK TABLES `tabClient Script` WRITE;
/*!40000 ALTER TABLE `tabClient Script` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabClient Script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustom Field`
--

DROP TABLE IF EXISTS `tabCustom Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustom Field` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `is_system_generated` tinyint(4) NOT NULL DEFAULT 0,
  `dt` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `fieldname` varchar(140) DEFAULT NULL,
  `insert_after` varchar(140) DEFAULT NULL,
  `length` int(11) NOT NULL DEFAULT 0,
  `link_filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`link_filters`)),
  `fieldtype` varchar(140) DEFAULT 'Data',
  `precision` varchar(140) DEFAULT NULL,
  `hide_seconds` tinyint(4) NOT NULL DEFAULT 0,
  `hide_days` tinyint(4) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL,
  `sort_options` tinyint(4) NOT NULL DEFAULT 0,
  `fetch_from` text DEFAULT NULL,
  `fetch_if_empty` tinyint(4) NOT NULL DEFAULT 0,
  `collapsible` tinyint(4) NOT NULL DEFAULT 0,
  `collapsible_depends_on` longtext DEFAULT NULL,
  `default` text DEFAULT NULL,
  `depends_on` longtext DEFAULT NULL,
  `mandatory_depends_on` longtext DEFAULT NULL,
  `read_only_depends_on` longtext DEFAULT NULL,
  `non_negative` tinyint(4) NOT NULL DEFAULT 0,
  `reqd` tinyint(4) NOT NULL DEFAULT 0,
  `unique` tinyint(4) NOT NULL DEFAULT 0,
  `is_virtual` tinyint(4) NOT NULL DEFAULT 0,
  `read_only` tinyint(4) NOT NULL DEFAULT 0,
  `ignore_user_permissions` tinyint(4) NOT NULL DEFAULT 0,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `print_hide` tinyint(4) NOT NULL DEFAULT 0,
  `print_hide_if_no_value` tinyint(4) NOT NULL DEFAULT 0,
  `print_width` varchar(140) DEFAULT NULL,
  `no_copy` tinyint(4) NOT NULL DEFAULT 0,
  `allow_on_submit` tinyint(4) NOT NULL DEFAULT 0,
  `in_list_view` tinyint(4) NOT NULL DEFAULT 0,
  `in_standard_filter` tinyint(4) NOT NULL DEFAULT 0,
  `in_global_search` tinyint(4) NOT NULL DEFAULT 0,
  `in_preview` tinyint(4) NOT NULL DEFAULT 0,
  `bold` tinyint(4) NOT NULL DEFAULT 0,
  `report_hide` tinyint(4) NOT NULL DEFAULT 0,
  `search_index` tinyint(4) NOT NULL DEFAULT 0,
  `allow_in_quick_entry` tinyint(4) NOT NULL DEFAULT 0,
  `ignore_xss_filter` tinyint(4) NOT NULL DEFAULT 0,
  `translatable` tinyint(4) NOT NULL DEFAULT 0,
  `hide_border` tinyint(4) NOT NULL DEFAULT 0,
  `show_dashboard` tinyint(4) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `permlevel` int(11) NOT NULL DEFAULT 0,
  `width` varchar(140) DEFAULT NULL,
  `columns` int(11) NOT NULL DEFAULT 0,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `dt` (`dt`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustom Field`
--

LOCK TABLES `tabCustom Field` WRITE;
/*!40000 ALTER TABLE `tabCustom Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustom Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDashboard`
--

DROP TABLE IF EXISTS `tabDashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDashboard` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `dashboard_name` varchar(140) DEFAULT NULL,
  `is_default` tinyint(4) NOT NULL DEFAULT 0,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `chart_options` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `dashboard_name` (`dashboard_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDashboard`
--

LOCK TABLES `tabDashboard` WRITE;
/*!40000 ALTER TABLE `tabDashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDashboard Chart`
--

DROP TABLE IF EXISTS `tabDashboard Chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDashboard Chart` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `chart_name` varchar(140) DEFAULT NULL,
  `chart_type` varchar(140) DEFAULT NULL,
  `report_name` varchar(140) DEFAULT NULL,
  `use_report_chart` tinyint(4) NOT NULL DEFAULT 0,
  `x_field` varchar(140) DEFAULT NULL,
  `source` varchar(140) DEFAULT NULL,
  `document_type` varchar(140) DEFAULT NULL,
  `parent_document_type` varchar(140) DEFAULT NULL,
  `based_on` varchar(140) DEFAULT NULL,
  `value_based_on` varchar(140) DEFAULT NULL,
  `group_by_type` varchar(140) DEFAULT 'Count',
  `group_by_based_on` varchar(140) DEFAULT NULL,
  `aggregate_function_based_on` varchar(140) DEFAULT NULL,
  `number_of_groups` int(11) NOT NULL DEFAULT 0,
  `is_public` tinyint(4) NOT NULL DEFAULT 0,
  `heatmap_year` varchar(140) DEFAULT NULL,
  `timespan` varchar(140) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `time_interval` varchar(140) DEFAULT NULL,
  `timeseries` tinyint(4) NOT NULL DEFAULT 0,
  `type` varchar(140) DEFAULT 'Line',
  `filters_json` longtext DEFAULT NULL,
  `dynamic_filters_json` longtext DEFAULT NULL,
  `custom_options` longtext DEFAULT NULL,
  `color` varchar(140) DEFAULT NULL,
  `last_synced_on` datetime(6) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `chart_name` (`chart_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDashboard Chart`
--

LOCK TABLES `tabDashboard Chart` WRITE;
/*!40000 ALTER TABLE `tabDashboard Chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDashboard Chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDashboard Chart Source`
--

DROP TABLE IF EXISTS `tabDashboard Chart Source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDashboard Chart Source` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `source_name` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `timeseries` tinyint(4) NOT NULL DEFAULT 0,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `source_name` (`source_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDashboard Chart Source`
--

LOCK TABLES `tabDashboard Chart Source` WRITE;
/*!40000 ALTER TABLE `tabDashboard Chart Source` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDashboard Chart Source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDefaultValue`
--

DROP TABLE IF EXISTS `tabDefaultValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDefaultValue` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `defvalue` text DEFAULT NULL,
  `defkey` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `defaultvalue_parent_defkey_index` (`parent`,`defkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDefaultValue`
--

LOCK TABLES `tabDefaultValue` WRITE;
/*!40000 ALTER TABLE `tabDefaultValue` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDefaultValue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocField`
--

DROP TABLE IF EXISTS `tabDocField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocField` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `fieldname` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `oldfieldname` varchar(140) DEFAULT NULL,
  `fieldtype` varchar(140) DEFAULT 'Data',
  `oldfieldtype` varchar(140) DEFAULT NULL,
  `options` text DEFAULT NULL,
  `search_index` tinyint(4) NOT NULL DEFAULT 0,
  `show_dashboard` tinyint(4) NOT NULL DEFAULT 0,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `set_only_once` tinyint(4) NOT NULL DEFAULT 0,
  `allow_in_quick_entry` tinyint(4) NOT NULL DEFAULT 0,
  `print_hide` tinyint(4) NOT NULL DEFAULT 0,
  `report_hide` tinyint(4) NOT NULL DEFAULT 0,
  `reqd` tinyint(4) NOT NULL DEFAULT 0,
  `bold` tinyint(4) NOT NULL DEFAULT 0,
  `in_global_search` tinyint(4) NOT NULL DEFAULT 0,
  `collapsible` tinyint(4) NOT NULL DEFAULT 0,
  `unique` tinyint(4) NOT NULL DEFAULT 0,
  `no_copy` tinyint(4) NOT NULL DEFAULT 0,
  `allow_on_submit` tinyint(4) NOT NULL DEFAULT 0,
  `show_preview_popup` tinyint(4) NOT NULL DEFAULT 0,
  `trigger` varchar(255) DEFAULT NULL,
  `collapsible_depends_on` longtext DEFAULT NULL,
  `mandatory_depends_on` longtext DEFAULT NULL,
  `read_only_depends_on` longtext DEFAULT NULL,
  `depends_on` longtext DEFAULT NULL,
  `permlevel` int(11) NOT NULL DEFAULT 0,
  `ignore_user_permissions` tinyint(4) NOT NULL DEFAULT 0,
  `width` varchar(10) DEFAULT NULL,
  `print_width` varchar(10) DEFAULT NULL,
  `columns` int(11) NOT NULL DEFAULT 0,
  `default` text DEFAULT NULL,
  `name_case` varchar(40) DEFAULT 'capitalize',
  `description` text DEFAULT NULL,
  `in_list_view` tinyint(4) NOT NULL DEFAULT 0,
  `fetch_if_empty` tinyint(4) NOT NULL DEFAULT 0,
  `in_filter` tinyint(4) NOT NULL DEFAULT 0,
  `remember_last_selected_value` tinyint(4) NOT NULL DEFAULT 0,
  `ignore_xss_filter` tinyint(4) NOT NULL DEFAULT 0,
  `print_hide_if_no_value` tinyint(4) NOT NULL DEFAULT 0,
  `allow_bulk_edit` tinyint(4) NOT NULL DEFAULT 0,
  `in_standard_filter` tinyint(4) NOT NULL DEFAULT 0,
  `in_preview` tinyint(4) NOT NULL DEFAULT 0,
  `read_only` tinyint(4) NOT NULL DEFAULT 0,
  `precision` varchar(140) DEFAULT NULL,
  `max_height` varchar(10) DEFAULT NULL,
  `length` int(11) NOT NULL DEFAULT 0,
  `translatable` tinyint(4) NOT NULL DEFAULT 0,
  `hide_border` tinyint(4) NOT NULL DEFAULT 0,
  `hide_days` tinyint(4) NOT NULL DEFAULT 0,
  `hide_seconds` tinyint(4) NOT NULL DEFAULT 0,
  `non_negative` tinyint(4) NOT NULL DEFAULT 0,
  `is_virtual` tinyint(4) NOT NULL DEFAULT 0,
  `not_nullable` tinyint(4) NOT NULL DEFAULT 0,
  `sort_options` tinyint(4) NOT NULL DEFAULT 0,
  `link_filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`link_filters`)),
  `fetch_from` text DEFAULT NULL,
  `documentation_url` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `label` (`label`),
  KEY `fieldtype` (`fieldtype`),
  KEY `fieldname` (`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocField`
--

LOCK TABLES `tabDocField` WRITE;
/*!40000 ALTER TABLE `tabDocField` DISABLE KEYS */;
INSERT INTO `tabDocField` VALUES ('9inp0c2614','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',8,'hide_days','Hide Days',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp0sbghp','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',31,'print_hide_if_no_value','Print Hide If No Value',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\"Int\", \"Float\", \"Currency\", \"Percent\"].indexOf(doc.fieldtype)!==-1',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp1aqoki','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',28,'allow_in_quick_entry','Allow in Quick Entry',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Tab Break\', \'Table\'], doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp1nf4sc','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',54,'unique','Unique',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp2f0fsq','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',40,'in_standard_filter','In List Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp2lgndc','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',68,'documentation_url','Documentation URL',NULL,'Data',NULL,'URL',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\"Tab Break\", \"Section Break\", \"Column Break\", \"Button\", \"HTML\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp3k5l8m','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',2,'label','Label','label','Data','Data',NULL,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'163','163',0,NULL,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp3l4npe','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',50,'column_break_13',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp45bgb4','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',52,'ignore_xss_filter','Ignore XSS Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,'Don\'t encode HTML tags like &lt;script&gt; or just characters like &lt; or &gt;, as they could be intentionally used in this field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp5ghtlg','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',49,'allow_bulk_edit','Allow Bulk Edit',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.fieldtype == \"Table\"',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp5j7g3j','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',63,'width','Width','width','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp5ppua8','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',17,'show_dashboard','Show Dashboard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Tab Break\"',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp5vap2o','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',13,'not_nullable','Not Nullable',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\"Check\", \"Currency\", \"Float\", \"Int\", \"Percent\", \"Rating\", \"Select\", \"Table\", \"Table MultiSelect\"], doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp65fokp','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',48,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp70vrg1','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',6,'length','Length',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\'Data\', \'Link\', \'Dynamic Link\', \'Password\', \'Select\', \'Read Only\', \'Attach\', \'Attach Image\', \'Int\'], doc.fieldtype)',0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp72ck9r','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',57,'remember_last_selected_value','Remember Last Selected Value',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.fieldtype == \'Link\')',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp7uiuru','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',27,'bold','Bold',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inp8mqurp','2021-08-23 17:21:28.345841','2024-08-17 15:55:54.537152','Administrator','Administrator',0,'DocType State','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpa5fu5o','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',44,'in_global_search','In Global Search',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:([\"Data\", \"Select\", \"Table\", \"Text\", \"Text Editor\", \"Link\", \"Small Text\", \"Long Text\", \"Read Only\", \"Heading\", \"Dynamic Link\"].indexOf(doc.fieldtype) !== -1)',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpavf3ju','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',35,'collapsible','Collapsible',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Section Break\"',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,255,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpb0c9hi','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',34,'depends_on','Display Depends On (JS)','depends_on','Code','Data','JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',255,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpbio4j4','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',7,'non_negative','Non Negative',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Int\", \"Float\", \"Currency\"], doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpbrk1sd','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',70,'oldfieldtype',NULL,'oldfieldtype','Data','Data',NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpc960t2','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',60,'read_only_depends_on','Read Only Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpcglk6b','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',15,'options','Options','options','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,'For Links, enter the DocType as range.\nFor Select, enter list of Options, each on a new line.',1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpdejh08','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',22,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpdiuilv','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',18,'link_filters','Link Filters',NULL,'JSON',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpe17a95','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',38,'list__search_settings_section','List / Search Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpe7ns5p','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',10,'reqd','Mandatory','reqd','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\"Section Break\", \"Column Break\", \"Button\", \"HTML\"], doc.fieldtype)',0,0,'50px','50px',0,'0',NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpel5ejl','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',20,'default','Default','default','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,1,0,0,0,0,0,NULL,'3rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpeo8rfg','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',14,'column_break_18',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpfrteer','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',39,'in_list_view','In List View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.is_virtual',0,0,'70px','70px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpi8o5n5','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',9,'hide_seconds','Hide Seconds',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpip9p5c','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',16,'sort_options','Sort Options',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.fieldtype === \'Select\'',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpiv9pcl','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',21,'name_case','Name Case',NULL,'Select',NULL,'\ncapitalize\nlowercase\nuppercase',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'capitalize',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,40,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpj3pa78','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',3,'fieldtype','Type','fieldtype','Select','Select','Autocomplete\nAttach\nAttach Image\nBarcode\nButton\nCheck\nCode\nColor\nColumn Break\nCurrency\nData\nDate\nDatetime\nDuration\nDynamic Link\nFloat\nFold\nGeolocation\nHeading\nHTML\nHTML Editor\nIcon\nImage\nInt\nJSON\nLink\nLong Text\nMarkdown Editor\nPassword\nPercent\nPhone\nRead Only\nRating\nSection Break\nSelect\nSignature\nSmall Text\nTab Break\nTable\nTable MultiSelect\nText\nText Editor\nTime',1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Data',NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpj903nc','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',46,'read_only','Read Only',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpjiio02','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',65,'columns','Columns',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,'Number of columns for a field in a List View or a Grid (Total Columns should be less than 11)',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpjj81on','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',61,'display','Display',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpk3cq45','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',69,'oldfieldname',NULL,'oldfieldname','Data','Data',NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpklne46','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',11,'is_virtual','Virtual',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpkrrohv','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',36,'collapsible_depends_on','Collapsible Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\"Section Break\" && doc.collapsible',0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpkvnmv8','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',45,'permissions','Permissions',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpl3balf','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',1,'label_and_type',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inplp714p','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',4,'fieldname','Name','fieldname','Data','Data',NULL,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inplr8vln','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',64,'max_height','Max Height',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpmv3tot','2021-08-23 17:21:28.345841','2024-08-17 15:55:54.537152','Administrator','Administrator',0,'DocType State','fields','DocType',3,'custom','Custom',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpn1ajjj','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',47,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: parent.is_submittable',0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpnt06ir','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',59,'mandatory_depends_on','Mandatory Depends On (JS)',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'3rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpntgvas','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',41,'in_preview','In Preview',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Table\', \'Table MultiSelect\'], doc.fieldtype);',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpoctffj','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',37,'hide_border','Hide Border',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Section Break\'',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpoesci6','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',5,'precision','Precision',NULL,'Select',NULL,'\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9',0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,NULL,'Set non-standard precision for a Float or Currency field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpp0nosq','2021-08-23 17:21:28.345841','2024-08-17 15:55:54.537152','Administrator','Administrator',0,'DocType State','fields','DocType',2,'color','Color',NULL,'Select',NULL,'Blue\nCyan\nGray\nGreen\nLight Blue\nOrange\nPink\nPurple\nRed\nYellow',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Blue',NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inppalhok','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',55,'no_copy','No Copy','no_copy','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inppnrdss','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',58,'column_break_38',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpptstur','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',32,'report_hide','Report Hide','report_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inppu1jil','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',53,'constraints_section','Constraints',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpqqg39p','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',51,'permlevel','Perm Level','permlevel','Int','Int',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Section Break\', \'Column Break\', \'Tab Break\'], doc.fieldtype)',0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpr1pfdh','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',26,'hidden','Hidden','hidden','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inprg1lla','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',12,'search_index','Index','search_index','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inprldjgg','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',66,'column_break_22',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inps0arhv','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',42,'column_break_35',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inptb1g0f','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',23,'fetch_from','Fetch From',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inptgd1rv','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',33,'column_break_28',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inptnj5d4','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',56,'set_only_once','Set only once',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inptp05aa','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',25,'visibility_section','Visibility',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpu0s5e5','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',29,'translatable','Translatable',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\'Data\', \'Select\', \'Text\', \'Small Text\', \'Text Editor\'].includes(doc.fieldtype)',0,0,NULL,NULL,0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpu4473o','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',24,'fetch_if_empty','Fetch on Save if Empty',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0',NULL,'If unchecked, the value will always be re-fetched on save.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpuacsvu','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',67,'description','Description','description','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'300px','300px',0,NULL,NULL,NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpucq67a','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',43,'in_filter','In Filter','in_filter','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpv8ci0p','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',19,'defaults_section','Defaults',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,'2rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpvfc86h','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',62,'print_width','Print Width',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,10,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inpvqoilo','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.585266','Administrator','Administrator',0,'DocField','fields','DocType',30,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50px','50px',0,'0',NULL,NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr0ij508','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',8,'read','Read','read','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'1','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr16vogt','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',21,'share','Share',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr23hsmh','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',12,'column_break_8',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr2qtlhu','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',11,'delete','Delete',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr39d9md','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',13,'submit','Submit','submit','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr58142q','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',18,'export','Export',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr7oe4es','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',6,'section_break_4','Permissions',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr823smi','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',16,'additional_permissions','Additional Permissions',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inr8u16ec','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',15,'amend','Amend','amend','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrb9r22j','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',7,'select','Select',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrc1fh98','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',10,'create','Create','create','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'1','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrgtkuna','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',5,'permlevel','Level','permlevel','Int','Int',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'40px','40px',0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrhh81gn','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',17,'report','Report',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inri2mrns','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',20,'column_break_19',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrj7ok9k','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',1,'role_and_level','Role and Level',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrkon8l5','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',19,'import','Import',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrm7n8s0','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',3,'if_owner','If user is the owner',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Apply this rule if the User is the Owner',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrmu5006','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',4,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrovvka7','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',2,'role','Role','role','Link','Link','Role',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'150px','150px',0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrp210ef','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',22,'print','Print',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrqvki46','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',9,'write','Write','write','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'1','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrrj7f3s','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',14,'cancel','Cancel','cancel','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'32px','32px',0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inrupptrd','2013-02-22 01:27:33.000000','2024-08-17 15:55:54.761270','Administrator','Administrator',0,'DocPerm','fields','DocType',23,'email','Email',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ins13itqg','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',4,'group','Group',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ins19h168','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',3,'action','Action / Route',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,4,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ins1j1jc1','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',7,'is_child_table','Is Child Table',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insdn7plr','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',1,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insedtoan','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',2,'action_type','Action Type',NULL,'Select',NULL,'Server Action\nRoute',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insh76df9','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',5,'group','Group',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inshujcku','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',6,'custom','Custom',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insi0en2b','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',4,'table_fieldname','Table Fieldname',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insibifue','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',6,'hidden','Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insjjvrl7','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',8,'custom','Custom',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inslc64n9','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',1,'link_doctype','Link DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9insnsh6uf','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',3,'parent_doctype','Parent DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'is_child_table',NULL,'is_child_table',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inso36dfe','2019-09-24 11:41:25.291377','2024-08-17 15:55:54.890213','Administrator','Administrator',0,'DocType Link','fields','DocType',2,'link_fieldname','Link Fieldname',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inst61ocn','2019-09-23 16:28:13.953520','2024-08-17 15:55:54.850212','Administrator','Administrator',0,'DocType Action','fields','DocType',5,'hidden','Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int2h5gsj','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',6,'fieldname','Fieldname',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: (!doc.ui_tour)',NULL,'eval: (!doc.ui_tour && (!doc.is_table_field || (doc.is_table_field && doc.parent_fieldname)))',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int2tjklv','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',20,'fieldtype','Fieldtype',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int40kqir','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',12,'position','Position',NULL,'Select',NULL,'Left\nLeft Center\nLeft Bottom\nTop\nTop Center\nTop Right\nRight\nRight Center\nRight Bottom\nBottom\nBottom Center\nBottom Right\nMid Center',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Bottom','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int4t9mdu','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',17,'offset_y','Offset Y',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int5odc77','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',19,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int5rgmlq','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',25,'child_doctype','Child Doctype',NULL,'Data',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int6ed964','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',23,'next_form_tour','Next Form Tour',NULL,'Link',NULL,'Form Tour',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int7n49di','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',14,'popover_element','Popover Element',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize','when clicked on element it will focus popover if present.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int845ejv','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',7,'element_selector','Element Selector',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:(doc.ui_tour)',NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,NULL,'capitalize','CSS selector for the element you want to highlight.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int860kpc','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',4,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int8n4nqa','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',8,'parent_element_selector','Parent Element Selector',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,NULL,'capitalize','Mozilla doesn\'t support :has() so you can pass parent selector here as workaround',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int8oet4n','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',1,'ui_tour','UI Tour',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int8vhe5h','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',16,'offset_x','Offset X',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9int9vf0q4','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',2,'is_table_field','Is Table Field',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inta68nie','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',9,'description','Description',NULL,'HTML Editor',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,4,NULL,'capitalize',NULL,1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intb4f5e4','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',21,'has_next_condition','Has Next Condition',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intfg42j7','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',22,'next_step_condition','Next Step Condition','condition','Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'has_next_condition',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intfsbjph','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',18,'next_on_click','Next on Click',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize','Move to next step when clicked inside highlighted area.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inthjp6m1','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',15,'modal_trigger','Modal Trigger',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize','Enable if on click\nopens modal.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inti3mm28','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',11,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inti9lq5v','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',24,'section_break_13','Hidden Fields',NULL,'Section Break',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intidsnji','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',13,'hide_buttons','Hide Buttons',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize','Hide Previous, Next and Close button on highlight dialog.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intp4hvab','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',3,'section_break_2',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intphponf','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',5,'parent_fieldname','Parent Field',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'is_table_field',NULL,'eval: (!doc.ui_tour || doc.is_table_field)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9intvj1vgm','2021-05-21 23:05:45.342114','2024-08-17 15:55:54.935050','Administrator','Administrator',0,'Form Tour Step','fields','DocType',10,'ondemand_description','Popover or Modal Description',NULL,'HTML Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: (doc.popover_element || doc.modal_trigger)',0,0,NULL,NULL,4,NULL,'capitalize',NULL,1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu33f7p1','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',12,'ui_tour','UI Tour',NULL,'Check',NULL,NULL,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu4o6cqt','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',15,'save_on_complete','Save on Completion',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu60dn3l','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',7,'new_document_form','New Document Form',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: (doc.ui_tour && doc.view_name == \"Form\")',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu71s8pn','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',17,'include_name_field','Include Name Field',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour && !doc.first_document)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu7lerd2','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',8,'page_name','Select Page',NULL,'Link',NULL,'Page',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:(doc.ui_tour && doc.view_name == \"Page\")',NULL,'eval:(doc.ui_tour && doc.view_name == \"Page\")',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu87uoa3','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',11,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inu9e6an4','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',6,'dashboard_name','Select Dashboard',NULL,'Link',NULL,'Dashboard',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour && doc.view_name == \"List\" && doc.list_name == \"Dashboard\")',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuf1md8r','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',9,'reference_doctype','Reference Document',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:(!doc.ui_tour)',NULL,'eval:(!doc.ui_tour || doc.ui_tour && [\"Workspaces\", \"Page\", \"Tree\"].indexOf(doc.view_name) == -1);',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuf7fafk','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',20,'steps','Steps',NULL,'Table',NULL,'Form Tour Step',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour || doc.reference_doctype)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inufed3ii','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',19,'section_break_3',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inufo7khb','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',16,'first_document','Show First Document Tour',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(!doc.ui_tour)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inug7afa2','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',13,'track_steps','Track Steps',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'ui_tour',0,0,NULL,NULL,0,'0','capitalize','The next tour will start from where the user left off.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuk8nu1h','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',3,'workspace_name','Select Workspace',NULL,'Link',NULL,'Workspace',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour && doc.view_name == \"Workspaces\")',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inukchgb1','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',5,'report_name','Select Report',NULL,'Link',NULL,'Report',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:(doc.ui_tour && doc.view_name == \"List\" && doc.list_name == \"Report\")',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inulo3m7p','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',10,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.ui_tour && doc.is_standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuov01e4','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',14,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuq3qmq5','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',18,'page_route','Page Route',NULL,'Small Text',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuqdqo3o','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',2,'view_name','View',NULL,'Select',NULL,'Workspaces\nList\nForm\nTree\nPage',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'ui_tour',NULL,'ui_tour',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuvh03v5','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',4,'list_name','Select List View',NULL,'Select',NULL,'List\nReport\nDashboard\nKanban\nGantt\nCalendar\nFile\nImage\nInbox\nMap',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:(doc.ui_tour && doc.view_name == \"List\")',NULL,'eval:(doc.ui_tour && doc.view_name == \"List\")',0,0,NULL,NULL,0,'List','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inuvjmj3g','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv06j9fl','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',52,'icon','Icon',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv08cutc','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',26,'description','Description','description','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv0nlnvv','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',22,'naming_rule','Naming Rule',NULL,'Select',NULL,'\nSet by user\nAutoincrement\nBy fieldname\nBy \"Naming Series\" field\nExpression\nExpression (old style)\nRandom\nUUID\nBy script',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,40,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv16214p','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',85,'fields','Fields','fields','Table','Table','DocField',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv1d89qh','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',33,'column_break_23',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv1qqh56','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',56,'email_settings_sb','Email Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv1t17mc','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',16,'track_views','Track Views',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','If enabled, document views are tracked, this can happen multiple times',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv2gnndv','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',81,'advanced','Advanced',NULL,'Section Break',NULL,NULL,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv2n48en','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',1,'form_builder_tab','Form',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv2oldcn','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',32,'max_attachments','Max Attachments','max_attachments','Int','Int',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv3ej3us','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',11,'editable_grid','Editable Grid',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'istable',0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv55pnd5','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',53,'color','Color',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv5gahp8','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',51,'document_type','Show in Module Section','document_type','Select','Select','\nDocument\nSetup\nSystem\nOther',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv5gf5c9','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',31,'nsm_parent_field','Parent Field (Tree)',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'is_tree',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv5io5l5','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',27,'documentation','Documentation Link',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','URL for documentation or help',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv5q1lfi','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',46,'sort_field','Default Sort Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'creation','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv5u9gdu','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',44,'search_fields','Search Fields','search_fields','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv6f22p4','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',41,'title_field','Title Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.show_title_field_in_link',NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv6hs8j3','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',78,'route','Route',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv6k8bbv','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',48,'default_view','Default View',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv6po67a','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',23,'autoname','Auto Name','autoname','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Naming Options:\n<ol><li><b>field:[fieldname]</b> - By Field</li><li><b>autoincrement</b> - Uses Databases\' Auto Increment feature</li><li><b>naming_series:</b> - By Naming Series (field called naming_series must be present)</li><li><b>Prompt</b> - Prompt user for a name</li><li><b>[series]</b> - Series by prefix (separated by a dot); for example PRE.#####</li>\n<li><b>format:EXAMPLE-{MM}morewords{fieldname1}-{fieldname2}-{#####}</b> - Replace all braced words (fieldnames, date words (DD, MM, YY), series) with their value. Outside braces, any characters can be used.</li></ol>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv7is80k','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',64,'permissions','Permissions','permissions','Table','Table','DocPerm',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv84sfm5','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',80,'website_search_field','Website Search Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'has_web_view',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv852sl3','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',42,'show_title_field_in_link','Show Title in Link Fields',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv8h4ut7','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',43,'translated_doctype','Translate Link Fields',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv8hu9oc','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',59,'email_append_to','Allow document creation via Email',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv96v4fu','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',17,'custom','Custom?',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv9oo0mj','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',21,'sb1','Naming',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inv9uf79b','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',34,'hide_toolbar','Hide Sidebar, Menu, and Comments','hide_toolbar','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invai322b','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',83,'migration_hash',NULL,NULL,'Data',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invb0r3d7','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',77,'index_web_pages_for_search','Index Web Pages for Search',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invbbju3n','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',73,'states','States',NULL,'Table',NULL,'DocType State',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invcssshg','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',49,'force_re_route_to_default_view','Force Re-route to Default View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invcuhl5i','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',58,'column_break_51',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invd80jqk','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',65,'restrict_to_domain','Restrict To Domain',NULL,'Link',NULL,'Domain',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invdb69c7','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',72,'document_states_section','Document States',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invdk5ns4','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',40,'view_settings','View Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invdnjqpf','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',68,'actions_section','Actions',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'actions',NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invegt1e2','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',24,'allow_rename','Allow Rename','allow_rename','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.naming_rule !== \"Autoincrement\"',0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inveo30g8','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',70,'links_section','Linked Documents',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'links',NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invetodug','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',9,'is_tree','Is Tree',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','Tree structures are implemented using Nested Set',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invfb5bdh','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',37,'allow_events_in_timeline','Allow events in timeline',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invfmv20e','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',25,'column_break_15',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invgb8l0d','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',3,'settings_tab','Settings',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9inviv58pp','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',66,'read_only','User Cannot Search','read_only','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invj1lld3','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',2,'form_builder','Form Builder',NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invjappc7','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',5,'module','Module','module','Link','Link','Module Def',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invjdvj8e','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',76,'allow_guest_to_view','Allow Guest to View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'has_web_view',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invjec7fd','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',14,'track_changes','Track Changes',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','If enabled, changes to the document are tracked and shown in timeline',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invjl4b1m','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',61,'sender_name_field','Sender Name Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'email_append_to',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invjvubjj','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',4,'sb0',NULL,NULL,'Section Break','Section Break',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invklsge2','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',63,'sb2','Permission Rules',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invkok3gk','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',75,'has_web_view','Has Web View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invlr5k59','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',55,'show_name_in_global_search','Make \"name\" searchable in Global Search',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invm0f2tp','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',10,'is_calendar_and_gantt','Is Calendar and Gantt',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','Enables Calendar and Gantt views.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invm80mtq','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',20,'queue_in_background','Queue in Background (BETA)',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.is_submittable',0,0,NULL,NULL,0,'0','capitalize','Enabling this will submit documents in background',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invmc91ju','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',28,'form_settings_section','Form Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invmq0eaf','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',7,'istable','Is Child Table','istable','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Child Tables are shown as a Grid in other DocTypes',0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invmss9si','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',86,'connections_tab','Connections',NULL,'Tab Break',NULL,NULL,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invn959bs','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',12,'quick_entry','Quick Entry',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable && !doc.issingle',0,0,NULL,NULL,0,'0','capitalize','Open a dialog with mandatory fields to create a new record quickly',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invniju4o','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',15,'track_seen','Track Seen',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','If enabled, the document is marked as seen, the first time a user opens it',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invnjd22i','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',50,'column_break_29',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invnjvirf','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',71,'links','Links',NULL,'Table',NULL,'DocType Link',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invnlark0','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',13,'cb01',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invo4stmh','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',6,'is_submittable','Is Submittable',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','Once submitted, submittable documents cannot be changed. They can only be Cancelled and Amended.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invo77p2b','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',30,'timeline_field','Timeline Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,NULL,'capitalize','Comments and Communications will be associated with this linked document',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invooeegs','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',60,'sender_field','Sender Email Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'email_append_to',NULL,'email_append_to',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invp13e3k','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',36,'allow_import','Allow Import (via Data Import Tool)',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invp7ejj6','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',38,'allow_auto_repeat','Allow Auto Repeat',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invpa71vc','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',35,'allow_copy','Hide Copy','allow_copy','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invpdjrvn','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',39,'make_attachments_public','Make Attachments Public by Default',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invqpkn80','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',47,'sort_order','Default Sort Order',NULL,'Select',NULL,'ASC\nDESC',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'DESC','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invr8jqke','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',57,'default_email_template','Default Email Template',NULL,'Link',NULL,'Email Template',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invrf83eg','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',74,'web_view','Web View',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.custom===0 && !doc.istable',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invrp3lr2','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',82,'engine','Database Engine',NULL,'Select',NULL,'InnoDB\nMyISAM',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.issingle',0,0,NULL,NULL,0,'InnoDB','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invrpjjm2','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',67,'in_create','User Cannot Create','in_create','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invrvlv5f','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',19,'is_virtual','Is Virtual',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invsgjb2f','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',8,'issingle','Is Single','issingle','Check','Check',NULL,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize','Single Types have only one record no tables associated. Values are stored in tabSingles',0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invsnu6g3','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',69,'actions','Actions',NULL,'Table',NULL,'DocType Action',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invt27881','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',18,'beta','Beta',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invt2l1q6','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',62,'subject_field','Subject Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'email_append_to',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invt9e4qt','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',84,'fields_section','Fields',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invt9qque','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',29,'image_field','Image Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Must be of type \"Attach Image\"',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invta0n2n','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',79,'is_published_field','Is Published Field',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'has_web_view',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invtrqiff','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',45,'default_print_format','Default Print Format',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9invv20bct','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','fields','DocType',54,'show_preview_popup','Show Preview Popup',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io14uds2p','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',6,'is_custom','Is Custom',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1cjmidu','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',15,'view_switcher','View Switcher',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1efm3vh','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',9,'navigation_settings_section','Navigation Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1euq94q','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',19,'dashboard','Dashboard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1f0dmkb','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',10,'search_bar','Search Bar',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1fhtfae','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',18,'timeline','Timeline',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1g95c11','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',1,'role_name','Role Name','role_name','Data','Data',NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1gf6bq3','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',12,'list_settings_section','List Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1i8dgf8','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',16,'form_settings_section','Form Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1imsqd8','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',17,'form_sidebar','Sidebar',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1l4253g','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',13,'list_sidebar','Sidebar',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1lv27h5','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',5,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','If disabled, this role will be removed from all users.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1n31uj2','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',2,'home_page','Home Page',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Route: Example \"/app\"',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1pv8ssh','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',14,'bulk_actions','Bulk Actions',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1q7q0sm','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',11,'notifications','Notifications',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1rck3qa','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',7,'desk_access','Desk Access',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1s1ln0o','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',3,'restrict_to_domain','Restrict To Domain',NULL,'Link',NULL,'Domain',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1tach58','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',8,'two_factor_auth','Two Factor Authentication',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io1v3eg6q','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','fields','DocType',4,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io310glg2','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',5,'label_help','Label Help',NULL,'HTML','HTML',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io325fvlc','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',10,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io32kqbeg','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',47,'allow_in_quick_entry','Allow in Quick Entry',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io32p97hh','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',48,'ignore_xss_filter','Ignore XSS Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Don\'t HTML Encode HTML tags like &lt;script&gt; or just characters like &lt; or &gt;, as they could be intentionally used in this field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io331uo5e','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',38,'no_copy','No Copy','no_copy','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3365iab','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',29,'reqd','Is Mandatory Field','reqd','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io33dt50i','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',42,'in_global_search','In Global Search',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:([\"Data\", \"Select\", \"Table\", \"Text\", \"Text Editor\", \"Link\", \"Small Text\", \"Long Text\", \"Read Only\", \"Heading\", \"Dynamic Link\"].indexOf(doc.fieldtype) !== -1)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io34cd5l7','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',39,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io35aahcb','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',51,'show_dashboard','Show Dashboard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io35ppqve','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',53,'permlevel','Permission Level','permlevel','Int','Int',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io376v3hc','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',22,'collapsible_depends_on','Collapsible Depends On',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\"Section Break\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io37h4ue8','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',9,'link_filters','Link Filters',NULL,'JSON',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io397a0pn','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',6,'fieldname','Fieldname','fieldname','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io39avg0o','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',50,'hide_border','Hide Border',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Section Break\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io39uf9vk','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',37,'print_width','Print Width',NULL,'Data',NULL,NULL,0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3bd8gb7','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',43,'in_preview','In Preview',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!in_list([\'Table\', \'Table MultiSelect\'], doc.fieldtype);',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3bhpv1f','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',14,'hide_days','Hide Days',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3bktv6q','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',52,'description','Field Description','description','Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'300px','300px',0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3d2bgnq','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',23,'default','Default Value','default','Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3debkdb','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',27,'properties',NULL,NULL,'Column Break','Column Break',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50%','50%',0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3e220tv','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',15,'options','Options','options','Small Text','Text',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3eu84re','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',34,'hidden','Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ge18bv','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',26,'read_only_depends_on','Read Only Depends On',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,255,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3gemi0t','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',3,'module','Module (for export)',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3gl5e65','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',40,'in_list_view','In List View',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3h5edmg','2013-02-22 01:27:34.000000','2024-08-17 15:55:55.526010','Administrator','Administrator',0,'Has Role','fields','DocType',1,'role','Role','role','Link','Link','Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3hjl9hr','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',19,'options_help','Options Help',NULL,'HTML','HTML',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3i13to0','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',25,'mandatory_depends_on','Mandatory Depends On',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,255,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3jvrrsc','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',55,'columns','Columns',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Number of columns for a field in a List View or a Grid (Total Columns should be less than 11)',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ksrs7o','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',17,'fetch_from','Fetch From',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ku4u5q','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',46,'search_index','Index',NULL,'Check',NULL,NULL,0,0,1,0,0,1,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3lfavkb','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',20,'section_break_11',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3lmdjqj','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',49,'translatable','Translatable',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\'Data\', \'Select\', \'Text\', \'Small Text\', \'Text Editor\'].includes(doc.fieldtype)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ltbrso','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',41,'in_standard_filter','In Standard Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3m7tjl9','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',4,'label','Label','label','Data','Data',NULL,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,1,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3m9ci0m','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',8,'length','Length',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\'Data\', \'Link\', \'Dynamic Link\', \'Password\', \'Select\', \'Read Only\', \'Attach\', \'Attach Image\', \'Int\'], doc.fieldtype)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3mdlklo','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',45,'report_hide','Report Hide','report_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3na5neo','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',18,'fetch_if_empty','Fetch on Save if Empty',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','If unchecked, the value will always be re-fetched on save.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3nqp92j','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',36,'print_hide_if_no_value','Print Hide If No Value',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\"Int\", \"Float\", \"Currency\", \"Percent\"].indexOf(doc.fieldtype)!==-1',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3o9umi1','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',44,'bold','Bold',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3odp1eo','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',12,'precision','Precision',NULL,'Select',NULL,'\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,'capitalize','Set non-standard precision for a Float or Currency field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3offmgb','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',31,'is_virtual','Is Virtual',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ons25p','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',24,'depends_on','Depends On',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,255,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ot1jr6','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',33,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Link\"',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3otcren','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',21,'collapsible','Collapsible',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\"Section Break\"',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3pd0s0v','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',28,'non_negative','Non Negative',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Int\", \"Float\", \"Currency\"], doc.fieldtype)',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3pkfl58','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',11,'fieldtype','Field Type','fieldtype','Select','Select','Autocomplete\nAttach\nAttach Image\nBarcode\nButton\nCheck\nCode\nColor\nColumn Break\nCurrency\nData\nDate\nDatetime\nDuration\nDynamic Link\nFloat\nFold\nGeolocation\nHeading\nHTML\nHTML Editor\nIcon\nImage\nInt\nJSON\nLink\nLong Text\nMarkdown Editor\nPassword\nPercent\nPhone\nRead Only\nRating\nSection Break\nSelect\nSignature\nSmall Text\nTab Break\nTable\nTable MultiSelect\nText\nText Editor\nTime',0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Data','capitalize',NULL,1,0,1,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,1,NULL,NULL,NULL),('9io3r9qtt4','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',13,'hide_seconds','Hide Seconds',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Duration\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3ra0gge','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',16,'sort_options','Sort Options',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.fieldtype === \'Select\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3s8p9rl','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',2,'dt','DocType','dt','Link','Link','DocType',1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,1,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3sjhs3o','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',54,'width','Width','width','Data','Data',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3stogbd','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',32,'read_only','Read Only',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3t2r90n','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',7,'insert_after','Insert After','insert_after','Select','Select',NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Select the label after which you want to insert new field.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3t3moop','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',35,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3tt4hdp','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',1,'is_system_generated','Is System Generated',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io3v9u9cg','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','fields','DocType',30,'unique','Unique',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io44cq98e','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',5,'doc_type','DocType',NULL,'Link',NULL,'DocType',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io461qa1e','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',13,'value','Set Value',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','New value to be set',1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io474rnhs','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',12,'property_type','Property Type',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io493k3a7','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',9,'module','Module (for export)',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4ceoghj','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',3,'sb0',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4hk5fpk','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',8,'column_break0',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4j3ah3b','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',10,'section_break_9',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4oq5k8n','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',11,'property','Property',NULL,'Data',NULL,NULL,1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4ps885i','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',14,'default_value','Default Value',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4r4d1v6','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',7,'row_name','Row Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','For DocType Link / DocType Action',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4rls8ae','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',6,'field_name','Field Name',NULL,'Data',NULL,NULL,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.doctype_or_field==\'DocField\'',0,0,NULL,NULL,0,NULL,'capitalize','ID (name) of the entity whose property is to be set',0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4t8vgvm','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',2,'help','Help',NULL,'HTML',NULL,'<div class=\"alert\">Please don\'t update it as it can mess up your form. Use the Customize Form View and Custom Fields to set properties!</div>',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4uaanpp','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',1,'is_system_generated','Is System Generated',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io4vjugq4','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','fields','DocType',4,'doctype_or_field','Applied On',NULL,'Select',NULL,'\nDocField\nDocType\nDocType Link\nDocType Action\nDocType State',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,'eval:!doc.__islocal',NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io50h4umq','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',16,'allow_delete','Allow Delete',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.allow_multiple && doc.login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io50jrict','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',55,'custom_css','Custom CSS',NULL,'Code',NULL,'CSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io50sva1f','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',12,'settings_tab','Settings',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io50ti5lj','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',9,'section_break_1',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io515fosh','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',22,'allow_comments','Allow Comments',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5178joh','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',11,'web_form_fields','Web Form Fields',NULL,'Table',NULL,'Web Form Field',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io52bre0l','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',23,'show_attachments','Show Attachments',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io52ek2l1','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',1,'form_tab','Form',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io52jp124','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',31,'list_setting_message','List Setting Message',NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io537574q','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',37,'website_sidebar','Website Sidebar',NULL,'Link',NULL,'Website Sidebar',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io53btn9c','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',8,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io54ir5kt','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',13,'login_required','Login Required',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.anonymous',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io556uilo','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',50,'meta_description','Meta Description',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io55df1ek','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',41,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io56dboed','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',42,'breadcrumbs','Breadcrumbs',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','List as [{\"label\": _(\"Jobs\"), \"route\":\"jobs\"}]',0,0,0,0,0,0,0,0,0,0,NULL,'140px',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io56enikl','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',40,'banner_image','Banner Image',NULL,'Attach Image',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io57acm0q','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',19,'apply_document_permissions','Apply Document Permissions',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io58g0pa9','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',21,'print_format','Print Format',NULL,'Link',NULL,'Print Format',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'allow_print',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io58g5bmk','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',30,'section_break_3','List Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'show_list',NULL,NULL,'eval:!doc.anonymous',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5a48gal','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',15,'allow_edit','Allow Editing After Submit',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ap79a7','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',39,'button_label','Submit Button Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Save','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5be42hs','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',6,'doc_type','Select DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5bonstd','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',33,'list_title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.login_required && doc.show_list',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5cpttq7','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',52,'meta_image','Meta Image',NULL,'Attach Image',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ctchsu','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',34,'list_columns','List Columns',NULL,'Table',NULL,'Web Form List Column',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.login_required && doc.show_list',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5d1fhml','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',38,'customization_tab','Customization',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5d4niej','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',48,'meta_section','Meta',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5dmvcvl','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',29,'condition_json','Condition JSON',NULL,'JSON',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5f1i210','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',2,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5fgra3g','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',7,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5gtmvp0','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',54,'client_script','Client Script',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','For help see <a href=\"https://frappeframework.com/docs/user/en/guides/portal-development/web-forms\" target=\"_blank\">Client Script API and Examples</a>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5haiie7','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',4,'published','Published',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ickvhb','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',24,'allow_incomplete','Allow Incomplete Forms',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Allow saving if mandatory fields are not filled',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5j7tgph','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',36,'show_sidebar','Show Sidebar',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5jl22ml','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',35,'section_break_4','Sidebar Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'show_sidebar',NULL,NULL,'eval:!doc.anonymous',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ju34oa','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',43,'section_break_5','After Submission',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'eval: doc.success_title || doc.success_message || doc.success_url',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5kfjobc','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',5,'column_break_vdhm',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5lc4u3e','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',49,'meta_title','Meta Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5m8qnja','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',25,'section_break_2',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5m9pebd','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',45,'success_url','Success URL',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Go to this URL after completing the form',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5nck706','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',27,'condition_section',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5o43ns2','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',47,'success_message','Success Message',NULL,'Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Message to be displayed on successful completion',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5o6da43','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',3,'route','Route',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5p7olol','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',46,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ql9bmb','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',51,'column_break_khxs',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5r92pfd','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',18,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5rm6p0u','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',32,'show_list','Show List',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5rt411l','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',53,'section_break_6','Scripting / Style',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'eval: doc.client_script || doc.custom_css',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5saiput','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',44,'success_title','Success Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5sgflrn','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',10,'introduction_text','Introduction',NULL,'Text Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5t13erh','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',20,'allow_print','Allow Print',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5t6sbs7','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',14,'allow_multiple','Allow Multiple Responses',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5ta1gh8','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',17,'anonymous','Anonymous',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Receive anonymous response',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5uji403','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',26,'max_attachment_size','Max Attachment Size (in MB)',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io5vnjj9e','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','fields','DocType',28,'condition_description','Condition Description',NULL,'HTML',NULL,'<p>Multiple webforms can be created for a single doctype. Add filters specific to this webform to display correct record after submission.</p><p>For Example:</p>\n<p>If you create a separate webform every year to capture feedback from employees add a \n field named year in doctype and add a filter <b>year = 2023</b></p>\n',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io6el08es','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','fields','DocType',4,'template','Template',NULL,'Code',NULL,'Jinja',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io6eojfjs','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','fields','DocType',3,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'standard',NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io6fi07cc','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','fields','DocType',5,'fields','Fields',NULL,'Table',NULL,'Web Template Field',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io6s70tk3','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','fields','DocType',2,'standard','Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io6vif064','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','fields','DocType',1,'type','Type',NULL,'Select',NULL,'Component\nSection\nNavbar\nFooter',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Section','capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io70ghuuv','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',16,'mandatory_depends_on','Mandatory Depends On',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io718gpnn','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',6,'target','Target',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io72mqlhr','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',9,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io757sbg9','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',18,'read_only_depends_on','Read Only Depends On',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io76lq3tj','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',2,'enabled','Enabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io77frafj','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',5,'reqd','Mandatory',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io77hvi2d','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',5,'role','Role',NULL,'Link',NULL,'Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io77iqo3h','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',4,'reference_doctype','Reference Document Type',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io78g5100','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',4,'allow_read_on_all_link_options','Allow Read On All Link Options',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype === \'Link\' && parent.login_required',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io797u0oi','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',3,'route','Route',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,3,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7bm86us','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',12,'max_value','Max Value',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.fieldtype==\'Int\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7d2rqjt','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',22,'default','Default',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7degfg3','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',11,'max_length','Max Length',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7f3acjp','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',7,'show_in_filter','Show in filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7hnf5rc','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',6,'read_only','Read Only',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7j28rv0','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',8,'hidden','Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7kml318','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',13,'precision','Precision',NULL,'Select',NULL,'\n0\n1\n2\n3\n4\n5\n6\n7\n8\n9',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,0,NULL,NULL,0,NULL,'capitalize','Set non-standard precision for a Float or Currency field',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7kohve7','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',15,'depends_on','Display Depends On',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7kr0ogl','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',3,'label','Custom Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7ncdu82','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',21,'column_break_8',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7pbse04','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',17,'column_break_16',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7pp7fkh','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',19,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7rsptci','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',14,'property_depends_on_section','Property Depends On',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7sf9ftr','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',2,'fieldtype','Fieldtype',NULL,'Select',NULL,'Attach\nAttach Image\nCheck\nCurrency\nColor\nData\nDate\nDatetime\nDuration\nFloat\nHTML\nInt\nLink\nPassword\nPhone\nRating\nSelect\nSignature\nSmall Text\nText\nText Editor\nTable\nTime\nSection Break\nColumn Break\nPage Break',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7sp9859','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',1,'fieldname','Field',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7un4gtb','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',20,'description','Description',NULL,'Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7vgjf67','2014-09-01 14:14:14.292173','2024-08-17 15:55:55.913087','Administrator','Administrator',0,'Web Form Field','fields','DocType',10,'options','Options',NULL,'Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io7vj503i','2016-03-30 01:39:20.586927','2024-08-17 15:55:55.979668','Administrator','Administrator',0,'Portal Menu Item','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8193shr','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',11,'parent_document_type','Parent Document Type',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.type === \'Document Type\'',0,0,NULL,NULL,0,NULL,'capitalize','The document type selected is a child table, so the parent document type is required.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io83tblhn','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',18,'show_percentage_stats','Show Percentage Stats',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io84nljsd','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',6,'method','Method',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Custom\'',NULL,'eval: doc.type == \'Custom\'',0,0,NULL,NULL,0,NULL,'capitalize','Set the path to a whitelisted function that will return the data for the number card in the format:\n\n<pre class=\"small text-muted\"><code>\n{\n	\"value\": value,\n	\"fieldtype\": \"Currency\",\n	\"route_options\": {\"from_date\": \"2023-05-23\"},\n	\"route\": [\"query-report\", \"Permitted Documents For User\"]\n}</code></pre>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io84s77go','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',14,'is_public','Is Public',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','This card will be available to all Users if this is set',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8543m58','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',3,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io87ud0k7','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',17,'stats_section','Stats',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.type == \'Document Type\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io88dberk','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',9,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8akr7oj','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.is_standard',NULL,'eval: doc.is_standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8be8caj','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',15,'custom_configuration_section','Custom Configuration',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.type == \'Custom\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8buij6m','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',25,'color','Color',NULL,'Color',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8c078gn','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',5,'report_name','Report Name',NULL,'Link',NULL,'Report',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Report\'',NULL,'eval: doc.type == \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8d7rjeo','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',10,'document_type','Document Type',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Document Type\'',NULL,'eval: doc.type == \'Document Type\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8eenaai','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',24,'section_break_16',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8el6h4i','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',4,'type','Type',NULL,'Select',NULL,'Document Type\nReport\nCustom',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8j1qn50','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',7,'function','Function',NULL,'Select',NULL,'Count\nSum\nAverage\nMinimum\nMaximum',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Document Type\'',NULL,'eval: doc.type == \'Document Type\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8jjp7a0','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',22,'dynamic_filters_section','Dynamic Filters Section',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8k6d49d','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',13,'report_function','Function',NULL,'Select',NULL,'Sum\nAverage\nMinimum\nMaximum',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Report\'',NULL,'eval: doc.type == \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8lqaume','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',12,'report_field','Field',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.type == \'Report\'',NULL,'eval: doc.type == \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8lsf7lu','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',20,'filters_section','Filters Section',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8mpoje9','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',21,'filters_json','Filters JSON',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8qea2rf','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',19,'stats_time_interval','Stats Time Interval',NULL,'Select',NULL,'Daily\nWeekly\nMonthly\nYearly',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.show_percentage_stats',0,0,NULL,NULL,0,'Daily','capitalize','Show percentage difference according to this time interval',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8s5qebm','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',8,'aggregate_function_based_on','Aggregate Function Based On',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.function !== \'Count\'',NULL,'eval: doc.type === \'Document Type\' && doc.function !== \'Count\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8senqk1','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',16,'filters_config','Filters Configuration',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Set the filters here. For example:\n<pre class=\"small text-muted\"><code>\n[{\n	fieldname: \"company\",\n	label: __(\"Company\"),\n	fieldtype: \"Link\",\n	options: \"Company\",\n	default: frappe.defaults.get_user_default(\"Company\"),\n	reqd: 1\n},\n{\n	fieldname: \"account\",\n	label: __(\"Account\"),\n	fieldtype: \"Link\",\n	options: \"Account\",\n	reqd: 1\n}]\n</code></pre>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8tq8rnh','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',23,'dynamic_filters_json','Dynamic Filters JSON',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io8vl5m7k','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','fields','DocType',1,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,'eval: !frappe.boot.developer_mode',NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io90cgj97','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',32,'custom_options','Custom Options',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Ex: \"colors\": [\"#d1d8dd\", \"#ff5858\"]',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io91ip1ag','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',27,'filters_section','Filters',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io91tqr6g','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',3,'chart_name','Chart Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io94q7mb3','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',37,'roles','Roles',NULL,'Table',NULL,'Has Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','If set, only user with these roles can access this chart. If not set, DocType or Report permissions will be used.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io959j4uj','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',35,'section_break_10',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io963tmng','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',31,'chart_options_section','Chart Options',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io967t2es','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',9,'source','Chart Source',NULL,'Link',NULL,'Dashboard Chart Source',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.chart_type === \'Custom\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io96ikerr','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',19,'is_public','Is Public',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','This chart will be available to all Users if this is set',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io96m6ih3','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',15,'group_by_based_on','Group By Based On',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.chart_type === \'Group By\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io984a2jg','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',14,'group_by_type','Group By Type',NULL,'Select',NULL,'Count\nSum\nAverage',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.chart_type === \'Group By\'',0,0,NULL,NULL,0,'Count','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io99sk7rp','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',24,'time_interval','Time Interval',NULL,'Select',NULL,'Yearly\nQuarterly\nMonthly\nWeekly\nDaily',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.timeseries && doc.type !== \'Heatmap\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9ag6elm','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',1,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,'eval: !frappe.boot.developer_mode',NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9aludl1','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',34,'color','Color',NULL,'Color',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.chart_type !== \'Report\' && doc.type !== \'Heatmap\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9c8g89t','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',7,'x_field','X Field',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.report_name && !doc.use_report_chart',NULL,'eval:doc.chart_type == \'Report\' && doc.report_name && !doc.use_report_chart',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9clqh7v','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',4,'chart_type','Chart Type',NULL,'Select',NULL,'Count\nSum\nAverage\nGroup By\nCustom\nReport',0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9cnq7tg','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',33,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9dh6hdq','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',17,'number_of_groups','Number of Groups',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.chart_type === \'Group By\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9dp4qum','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',10,'document_type','Document Type',NULL,'Link',NULL,'DocType',0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.chart_type !== \'Custom\' && doc.chart_type !== \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9ejn2cl','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',13,'value_based_on','Value Based On',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: [\'Sum\', \'Average\'].includes(doc.chart_type)\n',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9ff0709','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',29,'dynamic_filters_section','Dynamic Filters',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9fm1r56','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',25,'timeseries','Time Series',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: ![\'Group By\', \'Report\'].includes(doc.chart_type)\n',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9ge8pro','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',36,'last_synced_on','Last Synced On',NULL,'Datetime',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9gi0nb4','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',12,'based_on','Time Series Based On',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.timeseries && [\'Count\', \'Sum\', \'Average\'].includes(doc.chart_type)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9inkf84','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',22,'from_date','From Date',NULL,'Date',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.timespan === \'Select Date Range\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9j2csqi','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',6,'use_report_chart','Use Report Chart',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.report_name',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9kjrccq','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',8,'y_axis','Y Axis',NULL,'Table',NULL,'Dashboard Chart Field',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.report_name && !doc.use_report_chart',NULL,'eval:doc.chart_type == \'Report\' && doc.report_name && !doc.use_report_chart',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9og4pbd','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',30,'dynamic_filters_json','Dynamic Filters JSON',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9rj0tq8','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',5,'report_name','Report Name',NULL,'Link',NULL,'Report',0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.chart_type === \'Report\'',NULL,'eval:doc.chart_type === \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9rqpec4','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',26,'type','Type',NULL,'Select',NULL,'Line\nBar\nPercentage\nPie\nDonut\nHeatmap',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Line','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9rt07k5','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.is_standard',NULL,'eval: doc.is_standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9rve8hh','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',18,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9s5blth','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',16,'aggregate_function_based_on','Aggregate Function Based On',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: [\'Sum\', \'Average\'].includes(doc.group_by_type)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9sgmbii','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',28,'filters_json','Filters JSON',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9t7mlea','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',21,'timespan','Timespan',NULL,'Select',NULL,'Last Year\nLast Quarter\nLast Month\nLast Week\nSelect Date Range',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.timeseries && doc.type !== \'Heatmap\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9vav0n3','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',11,'parent_document_type','Parent Document Type',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.chart_type !== \'Custom\' && doc.chart_type !== \'Report\'',0,0,NULL,NULL,0,NULL,'capitalize','The document type selected is a child table, so the parent document type is required.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9vlh9g1','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',23,'to_date','To Date',NULL,'Date',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.timespan === \'Select Date Range\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9io9vqtlfk','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','fields','DocType',20,'heatmap_year','Year',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.type == \'Heatmap\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioa3i3rjt','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',4,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: doc.is_standard',NULL,'eval: doc.is_standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioa6b5gqg','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',3,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,'eval: !frappe.boot.developer_mode',NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioa8lmoud','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',6,'chart_options','Chart Options',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Set Default Options for all charts on this Dashboard (Ex: \"colors\": [\"#d1d8dd\", \"#ff5858\"])',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioag2cras','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',7,'cards','Cards',NULL,'Table',NULL,'Number Card Link',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioaljik89','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',1,'dashboard_name','Dashboard Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioaqf572c','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',5,'charts','Charts',NULL,'Table',NULL,'Dashboard Chart Link',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioarfqq7o','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','fields','DocType',2,'is_default','Is Default',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioatk08a8','2020-04-30 18:27:48.255489','2024-08-17 15:55:56.265199','Administrator','Administrator',0,'Onboarding Permission','fields','DocType',1,'role','Role',NULL,'Link',NULL,'Role',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob1qo8r8','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',26,'value_to_validate','Value to Validate',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"Update Settings\" && doc.validate_action',NULL,'eval:doc.action == \"Update Settings\" && doc.validate_action',0,0,NULL,NULL,0,NULL,'capitalize','Use % for any non empty value.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob31lfls','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',21,'path','Path',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"Go to Page\"',NULL,'eval:doc.action == \"Go to Page\"',0,0,NULL,NULL,0,NULL,'capitalize','Example: #Tree/Account',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob5342ad','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',12,'reference_document','Reference Document',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"Create Entry\" || doc.action == \"Update Settings\" || doc.action == \"Create Entry\" || doc.action == \"Show Form Tour\"',NULL,'eval:doc.action == \"Create Entry\" || doc.action == \"Update Settings\" || doc.action == \"Create Entry\" || doc.action == \"Show Form Tour\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob6einal','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',17,'reference_report','Reference Report',NULL,'Link',NULL,'Report',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"View Report\"',NULL,'eval:doc.action == \"View Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob7q1ets','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',25,'field','Field',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"Update Settings\" && doc.validate_action',NULL,'eval:doc.action == \"Update Settings\" && doc.validate_action',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob818ola','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',18,'report_reference_doctype','Report Reference Doctype',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,'reference_report.ref_doctype',NULL),('9iob8rep2r','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',11,'column_break_7',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iob91lmbb','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',23,'callback_message','Callback Message',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"Go to Page\"',0,0,NULL,NULL,0,NULL,'capitalize','This will be shown in a modal after routing',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobap4sda','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',22,'callback_title','Callback Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"Go to Page\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobb01drh','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',10,'action_label','Action Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobb3as19','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',19,'report_type','Report Type',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"View Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,'reference_report.report_type',NULL),('9iobe0cpp2','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',6,'description','Description',NULL,'Markdown Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobff869p','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',20,'report_description','Report Description',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"View Report\"',NULL,'eval:doc.action == \"View Report\"',0,0,NULL,NULL,0,NULL,'capitalize','This will be shown to the user in a dialog after routing to the report',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobgkc1cd','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',4,'is_skipped','Is Skipped',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobh1l7ve','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',24,'validate_action','Validate Field',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"Update Settings\"',0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobiina37','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',7,'intro_video_url','Intro Video URL',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobij5fhe','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',8,'section_break_5',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobl55v4s','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',2,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioblhqpne','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',15,'form_tour','Form Tour',NULL,'Link',NULL,'Form Tour',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'show_form_tour',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobn3shfh','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',5,'description_section','Description',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Description to inform the user about any action that is going to be performed',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobona8dl','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',13,'show_full_form','Show Full Form?',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"Create Entry\"',0,0,NULL,NULL,0,'0','capitalize','Show full form instead of a quick entry modal',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobpo8uaq','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',16,'is_single','Is Single',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action == \"Create Entry\" || doc.action == \"Update Settings\" || doc.action == \"Create Entry\" || doc.action == \"Show Form Tour\"',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,'reference_document.issingle',NULL),('9iobqj5sdb','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',3,'is_complete','Is Complete',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobtta4ki','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',27,'video_url','Video URL',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.action == \"Watch Video\"',NULL,'eval:doc.action == \"Watch Video\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobua6fa0','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',9,'action','Action',NULL,'Select',NULL,'Create Entry\nUpdate Settings\nShow Form Tour\nView Report\nGo to Page\nWatch Video',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobv6tut6','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',14,'show_form_tour','Show Form Tour',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.action==\"Create Entry\" && doc.show_full_form',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iobv9dnj2','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioc2bjasm','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioc33d010','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',9,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioc4qhq0n','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',5,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocaalsr8','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',6,'success_message','Success Message',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocfgo5ed','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',2,'subtitle','Subtitle',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocij7puq','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',8,'is_complete','Is Complete',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocjr44q0','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',10,'steps','Steps',NULL,'Table',NULL,'Onboarding Step Map',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iockgqutu','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',4,'allow_roles','Allow Roles',NULL,'Table MultiSelect',NULL,'Onboarding Permission',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','System managers are allowed by default',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocle8e4e','2020-04-28 22:06:08.544187','2024-08-17 15:55:56.401212','Administrator','Administrator',0,'Onboarding Step Map','fields','DocType',1,'step','Step',NULL,'Link',NULL,'Onboarding Step',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocrt62mm','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',7,'documentation_url','Documentation URL',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iocvec4qr','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','fields','DocType',3,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod10fbfj','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',11,'only_for','Only for',NULL,'Link',NULL,'Country',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod1rl0fo','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',7,'link_type','Link Type',NULL,'Select',NULL,'DocType\nPage\nReport',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.type==\"Link\"','eval:doc.type!=\"Link\"',NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod39tvul','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',8,'link_to','Link To',NULL,'Dynamic Link',NULL,'link_type',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.type==\"Link\"','eval:doc.type!=\"Link\"',NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod4j7usj','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',13,'is_query_report','Is Query Report',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.link_type == \"Report\"',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod5frcrb','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',9,'column_break_7',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iod7fak56','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',6,'link_details_section','Link Details',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"Link\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodbe1lgi','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',5,'hidden','Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"Card Break\"',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodd6rmqc','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',12,'onboard','Onboard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioddqfvkb','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',1,'type','Type',NULL,'Select',NULL,'Link\nCard Break',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Link','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodef643f','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',14,'link_count','Link Count',NULL,'Int',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"Card Break\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodgkmj37','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',10,'dependencies','Dependencies',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodh8emg6','2020-01-23 13:44:03.882158','2024-08-17 15:55:56.578717','Administrator','Administrator',0,'Workspace Chart','fields','DocType',1,'chart_name','Chart Name',NULL,'Link',NULL,'Dashboard Chart',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodlpulbn','2020-01-23 13:44:03.882158','2024-08-17 15:55:56.578717','Administrator','Administrator',0,'Workspace Chart','fields','DocType',2,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodpo1lrg','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',4,'description','Description',NULL,'HTML Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"Card Break\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,'7rem',0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iodtpsk44','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',3,'icon','Icon',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"Card Break\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioduah85b','2020-11-16 15:30:45.784417','2024-08-17 15:55:56.519263','Administrator','Administrator',0,'Workspace Link','fields','DocType',2,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioe3te1un','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',10,'section_break_5','Count Filter',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"DocType\"  && frappe.boot.developer_mode',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioe7gfuio','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',2,'link_to','Link To',NULL,'Dynamic Link',NULL,'type',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type != \"URL\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeam8tap','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',6,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioecvhr76','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',8,'icon','Icon',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:frappe.boot.developer_mode',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeghthgt','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',4,'doc_view','DocType View',NULL,'Select',NULL,'\nList\nReport Builder\nDashboard\nTree\nNew\nCalendar\nKanban\nImage',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"DocType\"',0,0,NULL,NULL,0,NULL,'capitalize','Which view of the associated DocType should this shortcut take you to?',1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioej5nh36','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',3,'url','URL',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.type == \"URL\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeksqdui','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',9,'restrict_to_domain','Restrict to Domain',NULL,'Link',NULL,'Domain',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:frappe.boot.developer_mode',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioelijn49','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',1,'type','Type',NULL,'Select',NULL,'DocType\nReport\nPage\nDashboard\nURL',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioem70pi5','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',11,'stats_filter','Count Filter',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioep50ptq','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',12,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeptjudj','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',5,'kanban_board','Kanban Board',NULL,'Link',NULL,'Kanban Board',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.doc_view == \"Kanban\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeqr05m7','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',7,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioes9hv3m','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',13,'color','Color',NULL,'Color',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioeutu49n','2020-01-23 13:44:59.248426','2024-08-17 15:55:56.642402','Administrator','Administrator',0,'Workspace Shortcut','fields','DocType',14,'format','Format',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','For example: {} Open',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iof6us1f9','2023-02-15 01:16:26.216201','2024-08-17 15:55:56.742873','Administrator','Administrator',0,'Workspace Number Card','fields','DocType',1,'number_card_name','Number Card Name',NULL,'Link',NULL,'Number Card',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iofabaipt','2022-05-12 12:58:41.824496','2024-08-17 15:55:56.699308','Administrator','Administrator',0,'Workspace Quick List','fields','DocType',4,'section_break_4',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iofac3vkv','2022-05-12 12:58:41.824496','2024-08-17 15:55:56.699308','Administrator','Administrator',0,'Workspace Quick List','fields','DocType',1,'document_type','DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioffnqfdc','2022-05-12 12:58:41.824496','2024-08-17 15:55:56.699308','Administrator','Administrator',0,'Workspace Quick List','fields','DocType',5,'quick_list_filter','Quick List Filter',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iofj7vkbm','2022-05-12 12:58:41.824496','2024-08-17 15:55:56.699308','Administrator','Administrator',0,'Workspace Quick List','fields','DocType',2,'column_break_1',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iofkfftou','2022-05-12 12:58:41.824496','2024-08-17 15:55:56.699308','Administrator','Administrator',0,'Workspace Quick List','fields','DocType',3,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iofvtba7h','2023-02-15 01:16:26.216201','2024-08-17 15:55:56.742873','Administrator','Administrator',0,'Workspace Number Card','fields','DocType',2,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog2dtbhh','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',6,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog2nqqci','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',19,'tab_break_15','Shortcuts',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'shortcuts',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog5e5v4g','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',13,'is_hidden','Is Hidden',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog637hrf','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',22,'links','Links',NULL,'Table',NULL,'Workspace Link',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog64b5q4','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',2,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog65n83p','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',15,'number_cards_tab','Number Cards',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog6r4j1k','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',8,'icon','Icon',NULL,'Icon',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog83togl','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',12,'public','Public',NULL,'Check',NULL,NULL,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,1,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog8cpng4','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',14,'content','Content',NULL,'Long Text',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'[]','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog8i9etc','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',11,'hide_custom','Hide Custom DocTypes and Reports',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Checking this will hide custom doctypes and reports cards in Links section',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog8t9637','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',1,'label','Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iog90fm80','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',27,'roles_tab','Roles',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogac1q2a','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',9,'indicator_color','Indicator Color',NULL,'Select',NULL,'green\ncyan\nblue\norange\nyellow\ngray\ngrey\nred\npink\ndarkgrey\npurple\nlight-blue',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'doc.icon',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogb34l4g','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',20,'shortcuts','Shortcuts',NULL,'Table',NULL,'Workspace Shortcut',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogc2irv0','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',7,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogcgtskl','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',28,'roles','Roles',NULL,'Table',NULL,'Has Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogdnb9gs','2023-05-17 14:49:19.454932','2024-08-17 15:55:56.800660','Administrator','Administrator',0,'Workspace Custom Block','fields','DocType',1,'custom_block_name','Custom Block Name',NULL,'Link',NULL,'Custom HTML Block',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogdrimpd','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',17,'tab_break_2','Dashboards',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'charts',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogds6jut','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',18,'charts','Charts',NULL,'Table',NULL,'Workspace Chart',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioggbs8pa','2023-05-17 14:49:19.454932','2024-08-17 15:55:56.800660','Administrator','Administrator',0,'Workspace Custom Block','fields','DocType',2,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogkhgcau','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',26,'custom_blocks','Custom Blocks',NULL,'Table',NULL,'Workspace Custom Block',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogo0jft3','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',16,'number_cards','Number Cards',NULL,'Table',NULL,'Workspace Number Card',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogpngjo8','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',21,'tab_break_18','Link Cards',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'links',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogrfib7i','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',23,'quick_lists_tab','Quick Lists',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogruivib','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',3,'sequence_id','Sequence Id',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogsmm9ve','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',5,'parent_page','Parent Page',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogtnhk87','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',25,'custom_blocks_tab','Custom Blocks',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogtsepps','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',4,'for_user','For User',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogvj7sdi','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',24,'quick_lists','Quick Lists',NULL,'Table',NULL,'Workspace Quick List',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iogvnejlu','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','fields','DocType',10,'restrict_to_domain','Restrict to Domain',NULL,'Link',NULL,'Domain',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioh8lmevs','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',10,'section_break0',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioha149qi','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',3,'page_name','Page Name','page_name','Data','Data',NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohagissv','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',4,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohe34pij','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',5,'icon','icon',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohgev6gp','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',9,'standard','Standard','standard','Select','Select','Yes\nNo',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohi6qkg8','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',2,'page_html','Page HTML',NULL,'Section Break','Section Break',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohi88qei','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',1,'system_page','System Page',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohjtaqau','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',7,'module','Module','module','Link','Select','Module Def',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohp2fbd6','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',6,'column_break0',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohrkgafl','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',11,'roles','Roles','roles','Table','Table','Has Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.standard == \'Yes\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iohrp3i9u','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','fields','DocType',8,'restrict_to_domain','Restrict To Domain',NULL,'Link',NULL,'Domain',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi05rgf0','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',5,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,1,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,'ref_doctype.module',NULL),('9ioi0l53nc','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',2,'ref_doctype','Ref DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi0nna78','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',14,'columns_section','Columns',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'columns',NULL,NULL,'eval:doc.report_type != \"Custom Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi1f60vj','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',3,'reference_report','Reference Report',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi31c6b3','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',1,'report_name','Report Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi4kam6m','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',10,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi4sg29p','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',16,'section_break_6','Query / Script',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi59dube','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',17,'query','Query',NULL,'Code',NULL,'SQL',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type==\"Query Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi66r8uv','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',18,'report_script','Script',NULL,'Code',NULL,'Python',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type===\"Script Report\" && doc.is_standard===\"No\"',0,0,NULL,NULL,0,NULL,'capitalize','Filters will be accessible via <code>filters</code>. <br><br>Send output as <code>result = [result]</code>, or for old style <code>data = [columns], [result]</code>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi6i7r46','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',13,'filters','Filters',NULL,'Table',NULL,'Report Filter',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type != \"Custom Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi8e4bbk','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',7,'report_type','Report Type',NULL,'Select',NULL,'Report Builder\nQuery Report\nScript Report\nCustom Report',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioi9vslr6','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',19,'client_code_section','Client Code',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'javascript',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioib3lorp','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',6,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioibfslnb','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',20,'javascript','Javascript',NULL,'Code',NULL,'Javascript',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type==\"Script Report\" && doc.is_standard===\"No\"',0,0,NULL,NULL,0,NULL,'capitalize','JavaScript Format: frappe.query_reports[\'REPORTNAME\'] = {}',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioif4fbgu','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',8,'letter_head','Letter Head',NULL,'Link',NULL,'Letter Head',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.is_standard == \"No\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioihrcn5a','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',21,'json','JSON',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type==\"Report Builder\" || \"Custom Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioiiqj8ac','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',12,'filters_section','Filters',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'filters',NULL,NULL,'eval:doc.report_type != \"Custom Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioij2posl','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',15,'columns','Columns',NULL,'Table',NULL,'Report Column',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.report_type != \"Custom Report\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioik9kbk9','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',9,'add_total_row','Add Total Row',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioiopgcv8','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',11,'prepared_report','Prepared Report',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iois73rki','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',4,'is_standard','Is Standard',NULL,'Select',NULL,'No\nYes',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioiuifi3j','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',22,'permission_rules',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioivjb0ls','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','fields','DocType',23,'roles','Roles',NULL,'Table',NULL,'Has Role',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj04el4c','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',8,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'custom_format',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj0h0f10','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',16,'margin_left','Margin Left',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'15','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj0inmfa','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',28,'custom_html_help','Custom HTML Help',NULL,'HTML',NULL,'<h3>Custom CSS Help</h3>\n\n<p>Notes:</p>\n\n<ol>\n<li>All field groups (label + value) are set attributes <code>data-fieldtype</code> and <code>data-fieldname</code></li>\n<li>All values are given class <code>value</code></li>\n<li>All Section Breaks are given class <code>section-break</code></li>\n<li>All Column Breaks are given class <code>column-break</code></li>\n</ol>\n\n<h4>Examples</h4>\n\n<p>1. Left align integers</p>\n\n<pre><code>[data-fieldtype=\"Int\"] .value { text-align: left; }</code></pre>\n\n<p>1. Add border to sections except the last section</p>\n\n<pre><code>.section-break { padding: 30px 0px; border-bottom: 1px solid #eee; }\n.section-break:last-child { padding-bottom: 0px; border-bottom: 0px;  }</code></pre>\n',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj1s75k7','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',25,'page_number','Page Number',NULL,'Select',NULL,'Hide\nTop Left\nTop Center\nTop Right\nBottom Left\nBottom Center\nBottom Right',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Hide','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj20co49','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',26,'css_section',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.raw_printing',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj4dnf2g','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',17,'margin_right','Margin Right',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'15','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj76e89f','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',18,'align_labels_right','Align Labels to the Right',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioj78n3h1','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',10,'raw_printing','Raw Printing',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioja3l2po','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',33,'print_format_builder_beta','Print Format Builder Beta',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojanje58','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',22,'column_break_11',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojb5uefr','2019-02-06 07:55:29.579840','2024-08-17 15:55:57.106341','Administrator','Administrator',0,'Dashboard Chart Source','fields','DocType',3,'timeseries','Timeseries',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojbiifub','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',20,'line_breaks','Show Line Breaks after Sections',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojc1jcct','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',4,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojd6sv7g','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',9,'print_format_type','Print Format Type',NULL,'Select',NULL,'Jinja\nJS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'custom_format',0,0,NULL,NULL,0,'Jinja','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojddc6i1','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',12,'raw_commands','Raw Commands',NULL,'Code',NULL,'Jinja',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'raw_printing',0,0,NULL,NULL,0,NULL,'capitalize','Any string-based printer languages can be used. Writing raw commands requires knowledge of the printer\'s native language provided by the printer manufacturer. Please refer to the developer manual provided by the printer manufacturer on how to write their native commands. These commands are rendered on the server side using the Jinja Templating Language.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojdu34m1','2019-02-06 07:55:29.579840','2024-08-17 15:55:57.106341','Administrator','Administrator',0,'Dashboard Chart Source','fields','DocType',1,'source_name','Source Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojedldri','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',15,'margin_bottom','Margin Bottom',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'15','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojf6ffsj','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',21,'absolute_value','Show Absolute Values',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'doc_type',0,0,NULL,NULL,0,'0','capitalize','If checked, negative numeric values of Currency, Quantity or Count would be shown as positive',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojh4kklu','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',19,'show_section_headings','Show Section Headings',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojihgb0k','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',6,'custom_format','Custom Format',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojj6f107','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',30,'print_format_help','Print Format Help',NULL,'HTML',NULL,'<h3>Print Format Help</h3>\n<hr>\n<h4>Introduction</h4>\n<p>Print Formats are rendered on the server side using the Jinja Templating Language. All forms have access to the <code>doc</code> object which contains information about the document that is being formatted. You can also access common utilities via the <code>frappe</code> module.</p>\n<p>For styling, the Boostrap CSS framework is provided and you can enjoy the full range of classes.</p>\n<hr>\n<h4>References</h4>\n<ol>\n	<li><a href=\"http://jinja.pocoo.org/docs/templates/\" target=\"_blank\">Jinja Templating Language</a></li>\n	<li><a href=\"http://getbootstrap.com\" target=\"_blank\">Bootstrap CSS Framework</a></li>\n</ol>\n<hr>\n<h4>Example</h4>\n<pre><code>&lt;h3&gt;{{ doc.select_print_heading or \"Invoice\" }}&lt;/h3&gt;\n&lt;div class=\"row\"&gt;\n	&lt;div class=\"col-md-3 text-right\"&gt;Customer Name&lt;/div&gt;\n	&lt;div class=\"col-md-9\"&gt;{{ doc.customer_name }}&lt;/div&gt;\n&lt;/div&gt;\n&lt;div class=\"row\"&gt;\n	&lt;div class=\"col-md-3 text-right\"&gt;Date&lt;/div&gt;\n	&lt;div class=\"col-md-9\"&gt;{{ doc.get_formatted(\"invoice_date\") }}&lt;/div&gt;\n&lt;/div&gt;\n&lt;table class=\"table table-bordered\"&gt;\n	&lt;tbody&gt;\n		&lt;tr&gt;\n			&lt;th&gt;Sr&lt;/th&gt;\n			&lt;th&gt;Item Name&lt;/th&gt;\n			&lt;th&gt;Description&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Qty&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Rate&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Amount&lt;/th&gt;\n		&lt;/tr&gt;\n		{%- for row in doc.items -%}\n		&lt;tr&gt;\n			&lt;td style=\"width: 3%;\"&gt;{{ row.idx }}&lt;/td&gt;\n			&lt;td style=\"width: 20%;\"&gt;\n				{{ row.item_name }}\n				{% if row.item_code != row.item_name -%}\n				&lt;br&gt;Item Code: {{ row.item_code}}\n				{%- endif %}\n			&lt;/td&gt;\n			&lt;td style=\"width: 37%;\"&gt;\n				&lt;div style=\"border: 0px;\"&gt;{{ row.description }}&lt;/div&gt;&lt;/td&gt;\n			&lt;td style=\"width: 10%; text-align: right;\"&gt;{{ row.qty }} {{ row.uom or row.stock_uom }}&lt;/td&gt;\n			&lt;td style=\"width: 15%; text-align: right;\"&gt;{{\n				row.get_formatted(\"rate\", doc) }}&lt;/td&gt;\n			&lt;td style=\"width: 15%; text-align: right;\"&gt;{{\n				row.get_formatted(\"amount\", doc) }}&lt;/td&gt;\n		&lt;/tr&gt;\n		{%- endfor -%}\n	&lt;/tbody&gt;\n&lt;/table&gt;</code></pre>\n<hr>\n<h4>Common Functions</h4>\n<table class=\"table table-bordered\">\n	<tbody>\n		<tr>\n			<td style=\"width: 30%;\"><code>doc.get_formatted(\"[fieldname]\", [parent_doc])</code></td>\n			<td>Get document value formatted as Date, Currency, etc. Pass parent <code>doc</code> for currency type fields.</td>\n		</tr>\n		<tr>\n			<td style=\"width: 30%;\"><code>frappe.db.get_value(\"[doctype]\", \"[name]\", \"fieldname\")</code></td>\n			<td>Get value from another document.</td>\n		</tr>\n	</tbody>\n</table>\n',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'custom_format',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojjo74gq','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',24,'font','Google Font',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.custom_format',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojkt78g1','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojm5ic0j','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',7,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojnog584','2019-02-06 07:55:29.579840','2024-08-17 15:55:57.106341','Administrator','Administrator',0,'Dashboard Chart Source','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojod41v3','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',3,'default_print_language','Default Print Language',NULL,'Link',NULL,'Language',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojoe67i2','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',32,'print_format_builder','Print Format Builder',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojoo38ek','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',13,'section_break_9','Style Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.custom_format',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojr85tbe','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',5,'standard','Standard','standard','Select','Select','No\nYes',1,0,0,0,0,0,0,1,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'No','capitalize',NULL,0,0,1,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojrhbr9s','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',31,'format_data','Format Data',NULL,'Code',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojsjscd6','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',1,'doc_type','DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,1,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojtv4k0d','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',23,'font_size','Font Size',NULL,'Int',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'14','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioju7rauc','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',11,'html','HTML','html','Code','Text Editor','Jinja',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.raw_printing',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojubpnmb','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',27,'css','Custom CSS',NULL,'Code',NULL,'CSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojut5ubo','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',14,'margin_top','Margin Top',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'15','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iojvia7bc','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','fields','DocType',29,'section_break_13',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'custom_format',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok02a6r0','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',36,'set_meta_tags','Add Custom Tags',NULL,'Button',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok078mtl','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',4,'dynamic_route','Dynamic Route',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Map route parameters into form variables. Example <code>/project/&lt;name&gt;</code>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok0gs5ea','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',26,'show_title','Show Title',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok1diq4o','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',11,'dynamic_template','Dynamic Template',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok1jqrg6','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',29,'start_date','Start Date',NULL,'Datetime',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok2bo7p6','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',15,'page_blocks','Page Building Blocks',NULL,'Table',NULL,'Web Page Block',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.content_type==\'Page Builder\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok2brq9l','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',2,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,1,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok32rdqb','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',12,'main_section','Main Section',NULL,'Text Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.content_type===\'Rich Text\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok38n3gr','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',34,'meta_description','Description',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok3m1hrl','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',13,'main_section_md','Main Section (Markdown)',NULL,'Markdown Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.content_type===\'Markdown\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok3rdaje','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',1,'section_title','Content',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok4aif23','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',25,'full_width','Full Width',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok4k3t12','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',44,'header','Header',NULL,'HTML Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','HTML for header section. Optional',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok6p696j','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',18,'context_script','Context Script',NULL,'Code',NULL,'Python',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','<p>Set context before rendering a template. Example:</p><p>\n</p><div><pre><code>\ncontext.project = frappe.get_doc(\"Project\", frappe.form_dict.name)\n</code></pre></div>',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok85kesi','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',27,'settings','Settings',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iok8ovcmm','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',8,'sb1','Content',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokb61e6v','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',7,'module','Module (for export)',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokcfcug9','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',31,'end_date','End Date',NULL,'Datetime',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokd7075a','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',9,'content_type','Content Type',NULL,'Select',NULL,'Rich Text\nMarkdown\nHTML\nPage Builder\nSlideshow',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Page Builder','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokemcsrk','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',10,'slideshow','Slideshow',NULL,'Link',NULL,'Website Slideshow',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.content_type==\'Slideshow\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokf12c58','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',39,'idx','Priority',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','0 is highest',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokfder8u','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',45,'breadcrumbs','Breadcrumbs',NULL,'Code',NULL,'JSON',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','List as [{\"label\": _(\"Jobs\"), \"route\":\"jobs\"}]',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokfeinn7','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',28,'publishing_dates_section','Publishing Dates',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokfjh3oq','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',41,'column_break_20',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokfp6rsv','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',23,'text_align','Text Align',NULL,'Select',NULL,'Left\nCenter\nRight',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokgn00tc','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',14,'main_section_html','Main Section (HTML)',NULL,'HTML Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.content_type===\'HTML\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokik4urb','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',22,'insert_style','Insert Style',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokla1kdu','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',32,'metatags_section','Meta Tags',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokn0pcch','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',3,'route','Route',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,1,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokndirat','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',38,'show_sidebar','Show Sidebar',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokom4vj4','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',42,'enable_comments','Enable Comments',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokovlfng','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',24,'css','CSS',NULL,'Code',NULL,'CSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'insert_style',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokpctnrv','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',16,'scripting_tab','Scripting',NULL,'Tab Break',NULL,NULL,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokpj0g48','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',5,'cb1',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'50%',NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokpk61hf','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',30,'column_break_30',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokqmfi1k','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',43,'sb2','Header and Breadcrumbs',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokrl9usq','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',6,'published','Published',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioks04lai','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',20,'javascript','Javascript',NULL,'Code',NULL,'Javascript',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioks3vorb','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',35,'meta_image','Image',NULL,'Attach Image',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokssr7pb','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',19,'custom_javascript','Script',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'javascript',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioktggn0l','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',37,'section_break_17','Sidebar and Comments',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioku14vaq','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',40,'website_sidebar','Website Sidebar',NULL,'Link',NULL,'Website Sidebar',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokud1vut','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',33,'meta_title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokv7pn8h','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',17,'context_section','Context',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'context_script',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iokvplqui','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','fields','DocType',21,'custom_css','Style',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'insert_style',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol137lq9','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',2,'theme','Theme',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol2g44p3','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',13,'text_color','Text Color',NULL,'Link',NULL,'Color',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol3rjg21','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',9,'button_shadows','Button Shadows',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol3ubcfg','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',23,'custom_js_section','Script',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol681eps','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',4,'custom','Custom?',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol6n1dhk','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',14,'light_color','Light Color',NULL,'Link',NULL,'Color',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol6qljj5','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',19,'custom_scss','Custom SCSS',NULL,'Code',NULL,'SCSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol76q3nf','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',10,'button_gradients','Button Gradients',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol7hoogb','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',22,'theme_url','Theme URL',NULL,'Data',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol9n767c','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',17,'stylesheet_section','Stylesheet',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iol9t75q7','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',5,'google_font','Google Font',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolbki22c','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',15,'dark_color','Dark Color',NULL,'Link',NULL,'Color',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolgki1ng','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',8,'button_rounded_corners','Button Rounded Corners',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolhqjmq4','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',21,'theme_scss','Theme',NULL,'Code',NULL,'SCSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolhtrjba','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',16,'background_color','Background Color',NULL,'Link',NULL,'Color',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioljcktk1','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',11,'column_break_11',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioljg6odg','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',6,'font_size','Font Size',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolku4fc1','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',7,'font_properties','Font Properties',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'wght@300;400;500;600;700;800','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioll7ahp6','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',12,'primary_color','Primary Color',NULL,'Link',NULL,'Color',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioltqvi83','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',1,'bootstrap_theme_section','Theme Configuration',NULL,'Tab Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolul33up','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',3,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Website','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioluqi3l6','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',20,'ignored_apps','Ignored Apps',NULL,'Table',NULL,'Website Theme Ignore App',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolvcvlbm','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',18,'custom_overrides','Custom Overrides',NULL,'Code',NULL,'SCSS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iolvr227t','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','fields','DocType',24,'js','JavaScript',NULL,'Code',NULL,'JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom3010b4','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',23,'property_section','Set Property After Alert',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom4dvutc','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',20,'condition','Condition',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','Optional: The alert will be sent if this expression is true',1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom4epdrf','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',10,'document_type','Document Type',NULL,'Link',NULL,'DocType',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom4nr9el','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',29,'message_sb','Message',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom5kc6u4','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',2,'is_standard','Is Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom83smu3','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',18,'sender_email','Sender Email',NULL,'Data',NULL,'Email',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom8at1io','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',3,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'is_standard',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom8sca91','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',26,'column_break_5','Recipients',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.channel !=\"Slack\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom95o993','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',33,'view_properties','View Properties (via Customize Form)',NULL,'Button',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom98ncr5','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',6,'slack_webhook_url','Slack Channel',NULL,'Link',NULL,'Slack Webhook URL',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.channel==\'Slack\'',NULL,'eval:doc.channel==\'Slack\'',0,0,NULL,NULL,0,NULL,'capitalize','To use Slack Channel, add a <a href=\"#List/Slack%20Webhook%20URL/List\">Slack Webhook URL</a>.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom9df5oh','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',30,'message_type','Message Type',NULL,'Select',NULL,'Markdown\nHTML\nPlain Text',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'is_standard',0,0,NULL,NULL,0,'Markdown','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iom9jdtiu','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',8,'subject','Subject',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval: in_list([\'Email\', \'Slack\', \'System Notification\'], doc.channel)',NULL,'eval: in_list([\'Email\', \'Slack\', \'System Notification\'], doc.channel)',0,0,NULL,NULL,0,NULL,'capitalize','To add dynamic subject, use jinja tags like\n\n<div><pre><code>{{ doc.name }} Delivered</code></pre></div>',1,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomacfqae','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',28,'recipients','Recipients',NULL,'Table',NULL,'Notification Recipient',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.channel!==\'Slack\' && !doc.send_to_all_assignees',NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomajkr0d','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',35,'attach_print','Attach Print',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomb1dptm','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',7,'filters','Filters',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomcn05hn','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',4,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomd0e43a','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',15,'value_changed','Value Changed',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.document_type && doc.event==\"Value Change\"',0,0,NULL,NULL,0,NULL,'capitalize','Send alert if this field\'s value changes',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iome0mntt','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',25,'property_value','Value To Be Set',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iome5e7e0','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',22,'html_7',NULL,NULL,'HTML',NULL,'<p><strong>Condition Examples:</strong></p>\n<pre>doc.status==\"Open\"<br>doc.due_date==nowdate()<br>doc.total &gt; 40000\n</pre>\n',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomimfj1j','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',12,'method','Trigger Method',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.event==\'Method\'',0,0,NULL,NULL,0,NULL,'capitalize','Trigger on valid methods like \"before_insert\", \"after_update\", etc (will depend on the DocType selected)',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomlos1m5','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',27,'send_to_all_assignees','Send To All Assignees',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.channel == \'Email\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomlqojaj','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',13,'date_changed','Reference Date',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.document_type && (doc.event==\"Days After\" || doc.event==\"Days Before\")',0,0,NULL,NULL,0,NULL,'capitalize','Send alert if date matches this field\'s value',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomltha6h','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',5,'channel','Channel',NULL,'Select',NULL,'Email\nSlack\nSystem Notification\nSMS',0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: !doc.disable_channel',0,0,NULL,NULL,0,'Email','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iommo9q5q','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',32,'message_examples','Message Examples',NULL,'HTML',NULL,'<h5>Message Example</h5>\n\n<pre>&lt;h3&gt;Order Overdue&lt;/h3&gt;\n\n&lt;p&gt;Transaction {{ doc.name }} has exceeded Due Date. Please take necessary action.&lt;/p&gt;\n\n&lt;!-- show last comment --&gt;\n{% if comments %}\nLast comment: {{ comments[-1].comment }} by {{ comments[-1].by }}\n{% endif %}\n\n&lt;h4&gt;Details&lt;/h4&gt;\n\n&lt;ul&gt;\n&lt;li&gt;Customer: {{ doc.customer }}\n&lt;li&gt;Amount: {{ doc.grand_total }}\n&lt;/ul&gt;\n</pre>',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iommtb5c9','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',31,'message','Message',NULL,'Code',NULL,'Jinja',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Add your message here','capitalize',NULL,0,0,0,0,1,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomn1n0pc','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',24,'set_property_after_alert','Set Property After Alert',NULL,'Select',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomnntr8e','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',36,'print_format','Print Format',NULL,'Link',NULL,'Print Format',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'attach_print',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomo38b4i','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',17,'send_system_notification','Send System Notification',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.channel !== \'System Notification\'',0,0,NULL,NULL,0,'0','capitalize','If enabled, the notification will show up in the notifications dropdown on the top right corner of the navigation bar.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomot4p2t','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',14,'days_in_advance','Days Before or After',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.document_type && (doc.event==\"Days After\" || doc.event==\"Days Before\")',0,0,NULL,NULL,0,'0','capitalize','Send days before or after the reference date',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomp17sii','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',34,'column_break_25','Print Settings',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'attach_print',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomppa98c','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',19,'section_break_9',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomr0rk2p','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',1,'enabled','Enabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'1','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomrsef5a','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',11,'col_break_1',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomsbephg','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',9,'event','Send Alert On',NULL,'Select',NULL,'\nNew\nSave\nSubmit\nCancel\nDays After\nDays Before\nValue Change\nMethod\nCustom',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomshuqf0','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',21,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iomv5fbh0','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','fields','DocType',16,'sender','Sender',NULL,'Link',NULL,'Email Account',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval: doc.channel == \'Email\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion08aiqu','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',4,'module','Module (for export)',NULL,'Link',NULL,'Module Def',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion0f15qu','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',1,'dt','DocType','dt','Link','Link','DocType',0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion0u636r','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',3,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion3ae92o','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','fields','DocType',4,'css','CSS',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion4tv3q2','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',5,'enabled','Enabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion6lce2j','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',6,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ion8tklv1','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','fields','DocType',3,'standard','Standard',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ionbjh487','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','fields','DocType',2,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioneg2nmi','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',8,'sample','Sample',NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ionf1ui7e','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',7,'script','Script','script','Code','Code','JS',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ionhhgqba','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','fields','DocType',5,'preview','Preview',NULL,'Attach Image',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ionoouoe8','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','fields','DocType',1,'print_style_name','Print Style Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ionroddi4','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','fields','DocType',2,'view','Apply To',NULL,'Select',NULL,'List\nForm',0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Form','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo0qcifa','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',11,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo385ju3','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',9,'module','Module (for export)',NULL,'Link',NULL,'Module Def',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo3mgh6n','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',4,'cron_format','Cron Format',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.event_frequency===\'Cron\'',0,0,NULL,NULL,0,NULL,'capitalize','<pre>*  *  *  *  *\n┬  ┬  ┬  ┬  ┬\n│  │  │  │  │\n│  │  │  │  └ day of week (0 - 6) (0 is Sunday)\n│  │  │  └───── month (1 - 12)\n│  │  └────────── day of month (1 - 31)\n│  └─────────────── hour (0 - 23)\n└──────────────────── minute (0 - 59)\n\n---\n\n* - Any value\n/ - Step values\n</pre>\n',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo50k5gl','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',17,'help_section','Help',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo6be6ms','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',10,'disabled','Disabled',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo734vnq','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',14,'enable_rate_limit','Enable Rate Limit',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioo9pl9rd','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',13,'rate_limiting_section','Rate Limiting',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.script_type===\'API\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iooaaocsj','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',15,'rate_limit_count','Request Limit',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'enable_rate_limit',0,0,NULL,NULL,0,'5','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioof69f8m','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',1,'script_type','Script Type',NULL,'Select',NULL,'DocType Event\nScheduler Event\nPermission Query\nAPI',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioog9hc33','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',7,'allow_guest','Allow Guest',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.script_type===\'API\'',0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iooiatelm','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',8,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioojf587p','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',3,'event_frequency','Event Frequency',NULL,'Select',NULL,'All\nHourly\nDaily\nWeekly\nMonthly\nYearly\nHourly Long\nDaily Long\nWeekly Long\nMonthly Long\nCron',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,'eval:doc.script_type == \"Scheduler Event\"',NULL,'eval:doc.script_type == \"Scheduler Event\"',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioolosltj','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',5,'doctype_event','DocType Event',NULL,'Select',NULL,'Before Insert\nBefore Validate\nBefore Save\nAfter Insert\nAfter Save\nBefore Rename\nAfter Rename\nBefore Submit\nAfter Submit\nBefore Cancel\nAfter Cancel\nBefore Discard\nAfter Discard\nBefore Delete\nAfter Delete\nBefore Save (Submitted Document)\nAfter Save (Submitted Document)\nBefore Print\nOn Payment Authorization\nOn Payment Paid\nOn Payment Failed\nOn Payment Charge Processed\nOn Payment Mandate Charge Processed\nOn Payment Mandate Acquisition Processed',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.script_type===\'DocType Event\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioom2aprp','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',2,'reference_doctype','Reference Document Type',NULL,'Link',NULL,'DocType',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:[\'DocType Event\', \'Permission Query\'].includes(doc.script_type)',0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,1,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioomd5k9b','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',6,'api_method','API Method',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.script_type===\'API\'',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iooptun3n','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',12,'script','Script',NULL,'Code',NULL,'Python',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iooqp7p5k','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',18,'help_html',NULL,NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioorgorse','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','fields','DocType',16,'rate_limit_seconds','Time Window (Seconds)',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'enable_rate_limit',0,0,NULL,NULL,0,'86400','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iop01gvpu','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',16,'timeline_doctype','Timeline DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iop1ge43k','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',2,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iop5gfhkr','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',18,'link_doctype','Link DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iop9pls4o','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',8,'column_break_7',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopa2aobd','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',17,'timeline_name','Timeline Name',NULL,'Dynamic Link',NULL,'timeline_doctype',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopc47j21','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',6,'communication_date','Date',NULL,'Datetime',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'Now','capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopckr96v','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',12,'reference_doctype','Reference Document Type',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopcqhg0n','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',4,'column_break_5',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopg8cpvo','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',15,'column_break_14',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopgf7kom','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',19,'link_name','Link Name',NULL,'Dynamic Link',NULL,'link_doctype',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopgorur9','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',3,'content','Message',NULL,'Text Editor',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,'400',NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iophpo7br','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',20,'user','User',NULL,'Link',NULL,'User',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,0,'__user','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopilaeja','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',9,'operation','Operation',NULL,'Select',NULL,'\nLogin\nLogout\nImpersonate',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopj13b1b','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',11,'reference_section','Reference',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopj9ik4k','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',10,'status','Status',NULL,'Select',NULL,'\nSuccess\nFailed\nLinked\nClosed',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopljuuf6','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',5,'additional_info','More Information',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioplk38bj','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',14,'reference_owner','Reference Owner',NULL,'Read Only',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,'reference_name.owner',NULL),('9iopnk3vlf','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',7,'ip_address','IP Address',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iopo8aqjp','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',21,'full_name','Full Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioppeq0tp','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',13,'reference_name','Reference Name',NULL,'Dynamic Link',NULL,'reference_doctype',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioppk80pf','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','fields','DocType',1,'subject','Subject',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioqacp8li','2019-07-17 16:22:31.300991','2024-08-17 15:55:57.809260','Administrator','Administrator',0,'Session Default Settings','fields','DocType',1,'session_defaults','Session Defaults',NULL,'Table',NULL,'Session Default',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioqibi8o5','2013-01-17 11:36:45.000000','2024-08-17 15:55:57.850007','Administrator','Administrator',0,'Patch Log','fields','DocType',1,'patch','Patch',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioquvr9ob','2013-01-17 11:36:45.000000','2024-08-17 15:55:57.850007','Administrator','Administrator',0,'Patch Log','fields','DocType',2,'skipped','Skipped',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioqvbsr66','2013-01-17 11:36:45.000000','2024-08-17 15:55:57.850007','Administrator','Administrator',0,'Patch Log','fields','DocType',3,'traceback','Traceback',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'eval:doc.skipped == 1',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior08cuo3','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',11,'rows_added',NULL,NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior1buct3','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',8,'section_break_gppi',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior3vbafv','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',4,'column_break_qmju',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior718ng3','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',5,'exact_copies','Exact Copies',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior7j4un7','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',3,'document','Document',NULL,'Dynamic Link',NULL,'doctype_name',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior7jfkff','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',4,'section_break_dfrx','Date Range',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,NULL,'eval: doc.start_date || doc.end_date',NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ior9u0dnn','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',11,'section_break_kvkb',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioracfr62','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',5,'start_date','Start Date',NULL,'Date',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorbrso5g','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',1,'doctype_name','DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorc0n664','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',12,'rows_removed_section','Rows Removed',NULL,'Section Break',NULL,NULL,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iordotbjn','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',7,'normalized_copies','Normalized Copies',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iordu733t','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',9,'stack_html','Stack Trace',NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorhp678p','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',10,'rows_added_section','Rows Added',NULL,'Section Break',NULL,NULL,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorj6min8','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',6,'column_break_ytzm',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorjo9lrt','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',13,'explain_result',NULL,NULL,'Text',NULL,NULL,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iork6tpi9','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',1,'index','Index',NULL,'Int',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorl21m8q','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',3,'duration','Duration',NULL,'Float',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorlkgipb','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',2,'column_break_peck',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorlsqr82','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',12,'sql_explain_html','SQL Explain',NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorq299np','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',9,'version_table','version_table',NULL,'HTML',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorqgqp5m','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',10,'stack',NULL,NULL,'Text',NULL,NULL,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorr4kqjq','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',2,'query','Query',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,2,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iorskto1h','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',6,'normalized_query','Normalized Query',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iortgvf7v','2023-08-01 17:04:12.173774','2024-08-17 15:55:57.955048','Administrator','Administrator',0,'Recorder Query','fields','DocType',8,'section_break_dygy',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iortmhsaa','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',7,'end_date','End Date',NULL,'Date',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iortrs2nf','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','fields','DocType',13,'rows_removed',NULL,NULL,'HTML',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ios2f70s9','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',3,'fieldname','Fieldname',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ios3mlsfe','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',6,'column_break_urrx',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ios7ib8tn','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',7,'options','Options',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ios7jppn1','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',1,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ios8qpnk7','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',4,'mandatory','Mandatory',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,1,'0','capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioscka0bq','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',2,'fieldtype','Fieldtype',NULL,'Select',NULL,'Check\nCurrency\nData\nDate\nDatetime\nDynamic Link\nFloat\nFold\nInt\nLink\nSelect\nTime',0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,2,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9ioshg5u6m','2020-10-08 13:09:36.034430','2024-08-17 15:55:58.059179','Administrator','Administrator',0,'Log Setting User','fields','DocType',1,'user','User',NULL,'Link',NULL,'User',0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iosmhbmp8','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',5,'wildcard_filter','Wildcard Filter',NULL,'Check',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize','Will add \"%\" before and after the query',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iosraelat','2020-01-14 11:38:58.016498','2024-08-17 15:55:58.006676','Administrator','Administrator',0,'Report Filter','fields','DocType',8,'default','Default',NULL,'Small Text',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iot58j3ol','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',10,'contribution_docname','Contribution Document Name',NULL,'Data',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iot8chn8s','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',1,'contributed','Contributed',NULL,'Check',NULL,NULL,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,'0','capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotcrtqiu','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',5,'context','Context',NULL,'Data',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotf47c6k','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',3,'section_break_4',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotgq0gdd','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',6,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iothpk8gv','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',2,'language','Language',NULL,'Link',NULL,'Language',1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotjjtb7h','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',9,'contribution_status','Contribution Status',NULL,'Select',NULL,'\nPending\nVerified\nRejected',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,'doc.contributed',0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,1,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotl27f7d','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',4,'source_text','Source Text',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize','If your data is in HTML, please copy paste the exact HTML code with the tags.',0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotur1hie','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',7,'translated_text','Translated Text',NULL,'Code',NULL,NULL,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,1,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL),('9iotv7pjon','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','fields','DocType',8,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,0,NULL,'capitalize',NULL,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocField` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocPerm`
--

DROP TABLE IF EXISTS `tabDocPerm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocPerm` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `permlevel` int(11) NOT NULL DEFAULT 0,
  `role` varchar(140) DEFAULT NULL,
  `match` varchar(255) DEFAULT NULL,
  `read` tinyint(4) NOT NULL DEFAULT 1,
  `write` tinyint(4) NOT NULL DEFAULT 1,
  `create` tinyint(4) NOT NULL DEFAULT 1,
  `submit` tinyint(4) NOT NULL DEFAULT 0,
  `cancel` tinyint(4) NOT NULL DEFAULT 0,
  `delete` tinyint(4) NOT NULL DEFAULT 1,
  `amend` tinyint(4) NOT NULL DEFAULT 0,
  `report` tinyint(4) NOT NULL DEFAULT 1,
  `export` tinyint(4) NOT NULL DEFAULT 1,
  `import` tinyint(4) NOT NULL DEFAULT 0,
  `share` tinyint(4) NOT NULL DEFAULT 1,
  `print` tinyint(4) NOT NULL DEFAULT 1,
  `email` tinyint(4) NOT NULL DEFAULT 1,
  `if_owner` tinyint(4) NOT NULL DEFAULT 0,
  `select` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocPerm`
--

LOCK TABLES `tabDocPerm` WRITE;
/*!40000 ALTER TABLE `tabDocPerm` DISABLE KEYS */;
INSERT INTO `tabDocPerm` VALUES ('9inuhf2npk','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9inuomijvk','2021-05-21 23:02:52.242721','2024-08-17 15:55:55.036865','Administrator','Administrator',0,'Form Tour','permissions','DocType',2,0,'Desk User',NULL,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('9inv879jiq','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9inve38bjo','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,0,1,1,0,0),('9io13f9ran','2013-01-08 15:50:01.000000','2024-08-17 15:55:55.358733','Administrator','Administrator',0,'Role','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9io388d5ji','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9io3pgei0j','2024-02-21 18:14:42.281748','2024-08-17 15:55:55.585191','Administrator','Administrator',0,'Custom Field','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9io46soq27','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9io4ju0du9','2013-01-10 16:34:04.000000','2024-08-17 15:55:55.686092','Administrator','Administrator',0,'Property Setter','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9io508emml','2014-09-01 14:08:48.624556','2024-08-17 15:55:55.749312','Administrator','Administrator',0,'Web Form','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,0,0,0,0),('9io696nhbs','2020-04-17 12:12:52.145708','2024-08-17 15:55:55.860438','Administrator','Administrator',0,'Web Template','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9io8ru5kni','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','permissions','DocType',2,0,'Dashboard Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9io8tin0qm','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9io8vvor4k','2020-04-15 18:06:39.444683','2024-08-17 15:55:56.030052','Administrator','Administrator',0,'Number Card','permissions','DocType',3,0,'Desk User',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9io986lbdf','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9io9ea8jt2','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','permissions','DocType',3,0,'Desk User',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9io9gav2kf','2019-01-10 12:28:06.282875','2024-08-17 15:55:56.118001','Administrator','Administrator',0,'Dashboard Chart','permissions','DocType',2,0,'Dashboard Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9ioamk2mhf','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9ioapvlerl','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','permissions','DocType',3,0,'Desk User',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9ioau0te0m','2019-01-10 12:54:40.938705','2024-08-17 15:55:56.210463','Administrator','Administrator',0,'Dashboard','permissions','DocType',2,0,'Dashboard Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iob5ev371','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iobu5uvi8','2020-04-14 15:50:25.782387','2024-08-17 15:55:56.310548','Administrator','Administrator',0,'Onboarding Step','permissions','DocType',2,0,'Desk User',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9ioc8aa2rj','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iocjn6e1n','2020-04-24 13:58:14.948024','2024-08-17 15:55:56.463095','Administrator','Administrator',0,'Module Onboarding','permissions','DocType',2,0,'Desk User',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9iog39i4nj','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','permissions','DocType',2,0,'Desk User',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iogrkgs23','2020-01-23 13:45:59.470592','2024-08-17 15:55:56.854043','Administrator','Administrator',0,'Workspace','permissions','DocType',1,0,'Workspace Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9ioh7guk1v','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','permissions','DocType',2,0,'System Manager',NULL,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0),('9iohcf4ovt','2012-12-20 17:16:49.000000','2024-08-17 15:55:56.961174','Administrator','Administrator',0,'Page','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,0,0,0,1,1,1,0,0),('9ioi7cvg77','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9ioi9747mo','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9ioii5k4gj','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','permissions','DocType',4,0,'Desk User',NULL,1,0,0,0,0,0,0,1,0,0,0,1,1,0,0),('9ioio61gta','2013-03-09 15:45:57.000000','2024-08-17 15:55:57.024090','Administrator','Administrator',0,'Report','permissions','DocType',3,0,'Report Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9ioj00n8lc','2019-02-06 07:55:29.579840','2024-08-17 15:55:57.106341','Administrator','Administrator',0,'Dashboard Chart Source','permissions','DocType',1,0,'System Manager',NULL,1,0,0,0,0,0,0,1,1,0,1,1,1,0,0),('9iojkc7i0b','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9iojmvkk5e','2013-01-23 19:54:43.000000','2024-08-17 15:55:57.158030','Administrator','Administrator',0,'Print Format','permissions','DocType',2,0,'Desk User',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1),('9ioju5l10h','2019-02-06 07:55:29.579840','2024-08-17 15:55:57.106341','Administrator','Administrator',0,'Dashboard Chart Source','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iok3an0da','2013-03-28 10:35:30.000000','2024-08-17 15:55:57.247382','Administrator','Administrator',0,'Web Page','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,0,0,0,1,1,0,0,0,0),('9iol1lifmb','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,0,0,0,0,0,0,0,0,0),('9iolufp219','2015-02-18 12:46:38.168929','2024-08-17 15:55:57.344352','Administrator','Administrator',0,'Website Theme','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,0,0,1,1,0,0,0,0,0),('9iomm6om5q','2014-07-11 17:18:09.923399','2024-08-17 15:55:57.416436','Administrator','Administrator',0,'Notification','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,0,0,0,0),('9ion1sfjdt','2017-08-17 01:25:56.910716','2024-08-17 15:55:57.534298','Administrator','Administrator',0,'Print Style','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9ionebp63n','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9ionmqns3g','2013-01-10 16:34:01.000000','2024-08-17 15:55:57.587489','Administrator','Administrator',0,'Client Script','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,0,1,0,0,1,1,1,0,0),('9ioop4g6nr','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','permissions','DocType',1,0,'Script Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0),('9iophunrd4','2017-10-05 11:10:38.780133','2024-08-17 15:55:57.722629','Administrator','Administrator',0,'Activity Log','permissions','DocType',1,0,'System Manager',NULL,1,0,0,0,0,0,0,1,0,0,1,0,1,0,0),('9ioq56a951','2013-01-17 11:36:45.000000','2024-08-17 15:55:57.850007','Administrator','Administrator',0,'Patch Log','permissions','DocType',2,0,'System Manager',NULL,1,0,0,0,0,0,0,1,1,0,0,1,1,0,0),('9ioqbnskgc','2013-01-17 11:36:45.000000','2024-08-17 15:55:57.850007','Administrator','Administrator',0,'Patch Log','permissions','DocType',1,0,'Administrator',NULL,1,0,0,0,0,0,0,1,0,0,0,1,1,0,0),('9ioqcan00g','2019-07-17 16:22:31.300991','2024-08-17 15:55:57.809260','Administrator','Administrator',0,'Session Default Settings','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,0,0,0,1,1,1,0,0),('9ioru5qo30','2023-08-14 13:06:24.520160','2024-08-17 15:55:57.902632','Administrator','Administrator',0,'Audit Trail','permissions','DocType',1,0,'System Manager',NULL,1,1,0,0,0,0,0,0,0,0,1,1,1,0,0),('9iotvl4ncu','2016-02-17 12:21:16.175465','2024-08-17 15:55:58.106103','Administrator','Administrator',0,'Translation','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,0,0);
/*!40000 ALTER TABLE `tabDocPerm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType`
--

DROP TABLE IF EXISTS `tabDocType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `search_fields` varchar(140) DEFAULT NULL,
  `issingle` tinyint(4) NOT NULL DEFAULT 0,
  `is_virtual` tinyint(4) NOT NULL DEFAULT 0,
  `is_tree` tinyint(4) NOT NULL DEFAULT 0,
  `istable` tinyint(4) NOT NULL DEFAULT 0,
  `editable_grid` tinyint(4) NOT NULL DEFAULT 1,
  `track_changes` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `restrict_to_domain` varchar(140) DEFAULT NULL,
  `app` varchar(255) DEFAULT NULL,
  `autoname` varchar(140) DEFAULT NULL,
  `naming_rule` varchar(40) DEFAULT NULL,
  `title_field` varchar(140) DEFAULT NULL,
  `image_field` varchar(140) DEFAULT NULL,
  `timeline_field` varchar(140) DEFAULT NULL,
  `sort_field` varchar(140) DEFAULT 'creation',
  `sort_order` varchar(140) DEFAULT 'DESC',
  `description` text DEFAULT NULL,
  `colour` varchar(255) DEFAULT NULL,
  `read_only` tinyint(4) NOT NULL DEFAULT 0,
  `in_create` tinyint(4) NOT NULL DEFAULT 0,
  `menu_index` int(11) DEFAULT NULL,
  `parent_node` varchar(255) DEFAULT NULL,
  `smallicon` varchar(255) DEFAULT NULL,
  `allow_copy` tinyint(4) NOT NULL DEFAULT 0,
  `allow_rename` tinyint(4) NOT NULL DEFAULT 1,
  `allow_import` tinyint(4) NOT NULL DEFAULT 0,
  `hide_toolbar` tinyint(4) NOT NULL DEFAULT 0,
  `track_seen` tinyint(4) NOT NULL DEFAULT 0,
  `max_attachments` int(11) NOT NULL DEFAULT 0,
  `print_outline` varchar(255) DEFAULT NULL,
  `document_type` varchar(140) DEFAULT NULL,
  `icon` varchar(140) DEFAULT NULL,
  `color` varchar(140) DEFAULT NULL,
  `tag_fields` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `_last_update` varchar(32) DEFAULT NULL,
  `engine` varchar(140) DEFAULT 'InnoDB',
  `default_print_format` varchar(140) DEFAULT NULL,
  `is_submittable` tinyint(4) NOT NULL DEFAULT 0,
  `show_name_in_global_search` tinyint(4) NOT NULL DEFAULT 0,
  `_user_tags` text DEFAULT NULL,
  `custom` tinyint(4) NOT NULL DEFAULT 0,
  `beta` tinyint(4) NOT NULL DEFAULT 0,
  `has_web_view` tinyint(4) NOT NULL DEFAULT 0,
  `allow_guest_to_view` tinyint(4) NOT NULL DEFAULT 0,
  `route` varchar(140) DEFAULT NULL,
  `is_published_field` varchar(140) DEFAULT NULL,
  `website_search_field` varchar(140) DEFAULT NULL,
  `email_append_to` tinyint(4) NOT NULL DEFAULT 0,
  `subject_field` varchar(140) DEFAULT NULL,
  `sender_field` varchar(140) DEFAULT NULL,
  `show_title_field_in_link` tinyint(4) NOT NULL DEFAULT 0,
  `migration_hash` varchar(140) DEFAULT NULL,
  `translated_doctype` tinyint(4) NOT NULL DEFAULT 0,
  `is_calendar_and_gantt` tinyint(4) NOT NULL DEFAULT 0,
  `quick_entry` tinyint(4) NOT NULL DEFAULT 0,
  `track_views` tinyint(4) NOT NULL DEFAULT 0,
  `queue_in_background` tinyint(4) NOT NULL DEFAULT 0,
  `documentation` varchar(140) DEFAULT NULL,
  `nsm_parent_field` varchar(140) DEFAULT NULL,
  `allow_events_in_timeline` tinyint(4) NOT NULL DEFAULT 0,
  `allow_auto_repeat` tinyint(4) NOT NULL DEFAULT 0,
  `make_attachments_public` tinyint(4) NOT NULL DEFAULT 0,
  `default_view` varchar(140) DEFAULT NULL,
  `force_re_route_to_default_view` tinyint(4) NOT NULL DEFAULT 0,
  `show_preview_popup` tinyint(4) NOT NULL DEFAULT 0,
  `default_email_template` varchar(140) DEFAULT NULL,
  `sender_name_field` varchar(140) DEFAULT NULL,
  `index_web_pages_for_search` tinyint(4) NOT NULL DEFAULT 1,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `module_index` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType`
--

LOCK TABLES `tabDocType` WRITE;
/*!40000 ALTER TABLE `tabDocType` DISABLE KEYS */;
INSERT INTO `tabDocType` VALUES ('Activity Log','2017-10-05 11:10:38.780133','2024-03-23 16:01:26.898094','Administrator','Administrator',0,0,'subject',0,0,0,0,0,0,'Core',NULL,NULL,NULL,NULL,'subject',NULL,NULL,'creation','DESC','Keep track of all update feeds',NULL,0,0,NULL,NULL,NULL,0,0,1,0,1,0,NULL,'Setup','fa fa-comment',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'51c325386586e94b5bdea78979714f8d',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Audit Trail','2023-08-14 13:06:24.520160','2024-03-23 16:01:28.029916','Administrator','Administrator',0,0,NULL,1,0,0,0,1,0,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,1,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'3a9df51dc8dfb9ef062a7591a2564b3e',0,0,0,0,0,NULL,NULL,0,0,0,'List',0,0,NULL,NULL,1,NULL,NULL,NULL),('Client Script','2013-01-10 16:34:01.000000','2024-03-23 16:01:29.862624','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Custom',NULL,NULL,'Prompt','Set by user',NULL,NULL,NULL,'creation','DESC','Adds a custom client script to a DocType',NULL,0,0,NULL,NULL,NULL,0,0,1,0,0,0,NULL,'Document','fa fa-glass',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'59571781a7c7d61cc571386e710a4ff6',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Custom Field','2024-02-21 18:14:42.281748','2024-04-12 16:25:50.349736','Administrator','Administrator',0,1,'dt,label,fieldtype,options',0,0,0,0,0,1,'Custom',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC','Adds a custom field to a DocType',NULL,0,0,NULL,NULL,NULL,0,0,1,0,0,0,NULL,'Setup','fa fa-glass',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'50d97f6760bca30c9df14d5e3606ead9',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Dashboard','2019-01-10 12:54:40.938705','2024-03-23 16:02:16.071715','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'field:dashboard_name',NULL,'dashboard_name',NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'7b8b4d9b7304a840686b0418f954ac36',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Dashboard Chart','2019-01-10 12:28:06.282875','2024-06-03 13:29:57.960271','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'field:chart_name','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'1897c22311a54e0936aac12dfb7781a9',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Dashboard Chart Source','2019-02-06 07:55:29.579840','2024-03-23 16:02:16.623353','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'field:source_name',NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'acba3da4e535518b9d3ef3439a184062',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('DocField','2013-02-22 01:27:33.000000','2024-04-12 16:27:34.546314','Administrator','Administrator',0,1,NULL,0,0,0,1,1,0,'Core',NULL,NULL,'hash','Random',NULL,NULL,NULL,'creation','ASC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'Setup',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'c1c1e2e99ee3f8c5b73882c5dc20b683',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('DocPerm','2013-02-22 01:27:33.000000','2024-03-23 16:02:18.443496','Administrator','Administrator',0,1,NULL,0,0,0,1,1,0,'Core',NULL,NULL,'hash',NULL,NULL,NULL,NULL,'creation','ASC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'Setup',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'1b95fc4a8217a9a66f01a6cd829ec3da',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('DocType','2013-02-18 13:36:19.000000','2024-03-29 16:09:26.114720','Administrator','Administrator',0,6,'module',0,0,0,0,0,1,'Core',NULL,NULL,'Prompt','Set by user',NULL,NULL,NULL,'creation','DESC','DocType is a Table / Form in the application.',NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,'Document','fa fa-bolt',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,1,NULL,0,0,0,0,'doctype',NULL,NULL,0,NULL,NULL,0,'1a2f7512af2f69103f5fe2f429f7e143',1,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('DocType Action','2019-09-23 16:28:13.953520','2024-03-23 16:03:21.873210','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'ca183da6fe3f3829e5ba0f390669eb99',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('DocType Link','2019-09-24 11:41:25.291377','2024-03-23 16:03:22.273487','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'9ff9f1b4a5a16be84adb41240ebc2750',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('DocType State','2021-08-23 17:21:28.345841','2024-03-23 16:03:22.416470','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'79616b313fca34e11939df41c888d7f3',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Form Tour','2021-05-21 23:02:52.242721','2024-03-23 16:03:25.983797','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'field:title','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'1334bfb98416252455a06adb41da1ae6',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Form Tour Step','2021-05-21 23:05:45.342114','2024-03-23 16:03:26.150327','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'6dbf460f6dcd3625e3045e44608e647d',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Has Role','2013-02-22 01:27:34.000000','2024-03-23 16:03:27.291168','Administrator','Administrator',0,1,NULL,0,0,0,1,1,0,'Core',NULL,NULL,'hash',NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'04ef2860084c2d3248bd0967f27ffcd0',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Log Setting User','2020-10-08 13:09:36.034430','2024-03-23 16:03:29.303855','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,'field:user',NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'5be73a60c352a4eb20ca6e9c3b7841ed',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Module Onboarding','2020-04-24 13:58:14.948024','2024-03-23 16:03:30.074327','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'Prompt',NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,1,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'114d8ba2514e279db7db5006e2211e20',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Notification','2014-07-11 17:18:09.923399','2024-07-04 05:53:40.595130','Administrator','Administrator',0,0,NULL,0,0,0,0,0,1,'Email',NULL,NULL,'Prompt','Set by user','subject',NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,'System','fa fa-envelope',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'f4f1513dae9bc033506c4cbf74c1368c',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Number Card','2020-04-15 18:06:39.444683','2024-03-23 16:03:32.189147','Administrator','Administrator',0,0,'label, document_type',0,0,0,0,1,1,'Desk',NULL,NULL,NULL,NULL,'label',NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'361d95c92cb2fbc99b83eb3e3575f1a4',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Onboarding Permission','2020-04-30 18:27:48.255489','2024-03-23 16:03:32.987560','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'46590dc85ef9f14e6f94bc2df6a4bfcd',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Onboarding Step','2020-04-14 15:50:25.782387','2024-03-23 16:03:33.078443','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'prompt','Set by user',NULL,NULL,NULL,'creation','DESC',NULL,NULL,1,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'2629d4b268fa15487e899c575763a5f3',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Onboarding Step Map','2020-04-28 22:06:08.544187','2024-03-23 16:03:33.218395','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'01dcef7fb38bedc346e6f7d6afcf9533',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Page','2012-12-20 17:16:49.000000','2024-03-23 16:03:33.657255','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Core',NULL,NULL,'field:page_name','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,'System','fa fa-file',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'ffc9b2b6e8289946994f792bb65330ef',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Patch Log','2013-01-17 11:36:45.000000','2024-03-23 16:03:34.014409','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Core',NULL,NULL,'hash','Random','patch',NULL,NULL,'creation','DESC','List of patches executed',NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'System','fa fa-cog',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'6ea9d881dbf07a2bd034e9cb5f2883b3',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Portal Menu Item','2016-03-30 01:39:20.586927','2024-03-23 16:03:34.594033','Administrator','Administrator',0,0,NULL,0,0,0,1,1,0,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'e54faa50a0f0f4571444fa0a80ffd782',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Print Format','2013-01-23 19:54:43.000000','2024-03-23 16:03:34.964767','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Printing',NULL,NULL,'Prompt','Set by user',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,'fa fa-print',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'6d638da68d53f2cb7a88edef23f584c5',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Print Style','2017-08-17 01:25:56.910716','2024-03-23 16:03:35.511731','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Printing',NULL,NULL,'field:print_style_name',NULL,NULL,'preview',NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'36d9d6d058bdd64211b8e667750b57b7',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Property Setter','2013-01-10 16:34:04.000000','2024-03-23 16:03:35.631784','Administrator','Administrator',0,1,'doc_type,property',0,0,0,0,0,1,'Custom',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC','Property Setter overrides a standard DocType or Field property',NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'Setup','fa fa-glass',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'d5eeec13dee5fc9ebcacbfb2cdabf7f8',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Recorder Query','2023-08-01 17:04:12.173774','2024-05-13 17:13:20.785329','Administrator','Administrator',0,0,NULL,0,1,0,1,1,0,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'57b0cda8b89d045203530377c6fea602',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Report','2013-03-09 15:45:57.000000','2024-03-23 16:03:36.343177','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Core',NULL,NULL,'field:report_name','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'System',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,1,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'17154d01ca17255f6e857a28c72a4476',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Report Filter','2020-01-14 11:38:58.016498','2024-03-23 16:03:36.633258','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'7bd250916d2a7331ab1f421236bbbe15',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Role','2013-01-08 15:50:01.000000','2024-03-23 16:03:36.854123','Administrator','Administrator',0,1,NULL,0,0,0,0,0,1,'Core',NULL,NULL,'field:role_name','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,'Document','fa fa-bookmark',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'08270051a7ec1db6d17c74396e286804',1,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Server Script','2019-09-30 11:56:57.943241','2024-05-08 03:21:54.169380','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Core',NULL,NULL,'Prompt','Set by user',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'86e676ed257b3d718fe8005ef336bc22',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Session Default Settings','2019-07-17 16:22:31.300991','2024-03-23 16:03:38.318576','Administrator','Administrator',0,0,NULL,1,0,0,0,1,1,'Core',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'5b36f2e070bb775f162edcd5d2a5ff18',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Translation','2016-02-17 12:21:16.175465','2024-03-23 16:03:59.551788','Administrator','Administrator',0,0,NULL,0,0,0,0,0,1,'Core',NULL,NULL,'hash','Random','source_text',NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,1,0,0,0,NULL,'Setup',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'172430e26bcf60ceb9b19a9d0de7ea07',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Web Form','2014-09-01 14:08:48.624556','2024-03-23 16:04:01.886581','Administrator','Administrator',0,0,NULL,0,0,0,0,0,1,'Website',NULL,NULL,NULL,NULL,'title',NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,'Document','icon-edit',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,1,0,NULL,'published',NULL,0,NULL,NULL,0,'13c93e527381861bb0fc0f83aeb71358',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Web Form Field','2014-09-01 14:14:14.292173','2024-04-15 16:11:58.469820','Administrator','Administrator',0,0,NULL,0,0,0,1,1,0,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'04d47cfd29bd4e4e4a77d9bd51b25244',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Web Page','2013-03-28 10:35:30.000000','2024-04-12 10:30:49.022735','Administrator','Administrator',0,1,'title',0,0,0,0,0,1,'Website',NULL,NULL,NULL,NULL,'title',NULL,NULL,'creation','DESC','Page to show on the website\n',NULL,0,0,NULL,NULL,NULL,0,0,1,0,0,0,NULL,'Document','fa fa-file-alt',NULL,NULL,NULL,NULL,'InnoDB',NULL,0,1,NULL,0,0,1,1,NULL,'published',NULL,0,NULL,NULL,0,'148212228ca62756d55a09a865154929',0,0,0,0,0,NULL,NULL,0,0,1,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Web Template','2020-04-17 12:12:52.145708','2024-03-23 16:04:02.852688','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Website',NULL,NULL,'Prompt','Set by user',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'f21ae192dfa7be8c8bf2c502df742f25',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Website Theme','2015-02-18 12:46:38.168929','2024-03-23 16:04:04.610086','Administrator','Administrator',0,0,NULL,0,0,0,0,0,1,'Website',NULL,NULL,'field:theme','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,1,0,0,0,NULL,'Setup',NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'329cd66f8c2b440e2a158091fcca341c',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Workspace','2020-01-23 13:45:59.470592','2024-05-30 17:30:36.791171','Administrator','Administrator',0,0,NULL,0,0,0,0,1,1,'Desk',NULL,NULL,'field:label','By fieldname',NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,1,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,1,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'9d86666d116088bc87e5069f690cbcb2',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Workspace Chart','2020-01-23 13:44:03.882158','2024-03-23 16:04:05.810019','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'6e1bce61b4daeff685080842b08ee6f8',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL),('Workspace Custom Block','2023-05-17 14:49:19.454932','2024-03-23 16:04:05.916601','Administrator','Administrator',0,0,NULL,0,0,0,1,1,0,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'ab28f4afea6592feb2a16c510f0ccc6d',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Workspace Link','2020-11-16 15:30:45.784417','2024-03-23 16:04:06.025772','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'c00fd27e3f2ca71599929dfdce0b3516',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Workspace Number Card','2023-02-15 01:16:26.216201','2024-03-23 16:04:06.156245','Administrator','Administrator',0,0,NULL,0,0,0,1,1,0,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'0651475add67be1131fbfbafad75861a',0,0,0,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Workspace Quick List','2022-05-12 12:58:41.824496','2024-03-23 16:04:06.260947','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'eb8bd1e2767edfad6243895ff814895e',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL),('Workspace Shortcut','2020-01-23 13:44:59.248426','2024-03-23 16:04:06.370271','Administrator','Administrator',0,0,NULL,0,0,0,1,1,1,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'creation','DESC',NULL,NULL,0,0,NULL,NULL,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'InnoDB',NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,0,NULL,NULL,0,'d78f732140eb3fab09470e61d0c73df6',0,0,1,0,0,NULL,NULL,0,0,0,NULL,0,0,NULL,NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType Action`
--

DROP TABLE IF EXISTS `tabDocType Action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType Action` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `label` varchar(140) DEFAULT NULL,
  `group` varchar(140) DEFAULT NULL,
  `action_type` varchar(140) DEFAULT NULL,
  `action` text DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `custom` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Action`
--

LOCK TABLES `tabDocType Action` WRITE;
/*!40000 ALTER TABLE `tabDocType Action` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocType Action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType Link`
--

DROP TABLE IF EXISTS `tabDocType Link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType Link` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `group` varchar(140) DEFAULT NULL,
  `link_doctype` varchar(140) DEFAULT NULL,
  `link_fieldname` varchar(140) DEFAULT NULL,
  `parent_doctype` varchar(140) DEFAULT NULL,
  `table_fieldname` varchar(140) DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `is_child_table` tinyint(4) NOT NULL DEFAULT 0,
  `custom` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType Link`
--

LOCK TABLES `tabDocType Link` WRITE;
/*!40000 ALTER TABLE `tabDocType Link` DISABLE KEYS */;
INSERT INTO `tabDocType Link` VALUES ('9inv0hjb24','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',14,'Rules','Assignment Rule','document_type',NULL,NULL,0,0,0),('9inv17ismk','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',9,'Views','Web Form','doc_type',NULL,NULL,0,0,0),('9inv5gh7j0','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',13,'Rules','Auto Repeat','reference_doctype',NULL,NULL,0,0,0),('9inv5jfng6','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',15,'Rules','Energy Point Rule','reference_doctype',NULL,NULL,0,0,0),('9inv64d1fp','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',5,'Customization','Client Script','dt',NULL,NULL,0,0,0),('9inv7fjvsi','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',1,'Views','Report','ref_doctype',NULL,NULL,0,0,0),('9inv8lf1fl','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',7,'Workflow','Webhook','webhook_doctype',NULL,NULL,0,0,0),('9inv9kvj56','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',11,'Views','Kanban Board','reference_doctype',NULL,NULL,0,0,0),('9invd89kfu','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',12,'Workflow','Onboarding Step','reference_document',NULL,NULL,0,0,0),('9invfpe9dt','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',4,'Customization','Custom Field','dt',NULL,NULL,0,0,0),('9invpt8trn','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',2,'Workflow','Workflow','document_type',NULL,NULL,0,0,0),('9invqa9rg5','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',8,'Views','Print Format','doc_type',NULL,NULL,0,0,0),('9invqgobh7','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',6,'Customization','Server Script','reference_doctype',NULL,NULL,0,0,0),('9invqn6lv5','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',3,'Workflow','Notification','document_type',NULL,NULL,0,0,0),('9invrvlc2j','2013-02-18 13:36:19.000000','2024-08-17 15:55:55.125747','Administrator','Administrator',0,'DocType','links','DocType',10,'Views','Calendar View','reference_doctype',NULL,NULL,0,0,0),('9ioo9j5jlo','2019-09-30 11:56:57.943241','2024-08-17 15:55:57.645524','Administrator','Administrator',0,'Server Script','links','DocType',1,NULL,'Scheduled Job Type','server_script',NULL,NULL,0,0,0);
/*!40000 ALTER TABLE `tabDocType Link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType State`
--

DROP TABLE IF EXISTS `tabDocType State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType State` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `color` varchar(140) DEFAULT 'Blue',
  `custom` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType State`
--

LOCK TABLES `tabDocType State` WRITE;
/*!40000 ALTER TABLE `tabDocType State` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabDocType State` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFile`
--

DROP TABLE IF EXISTS `tabFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFile` (
  `name` varchar(255) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `parent` varchar(255) DEFAULT NULL,
  `parentfield` varchar(255) DEFAULT NULL,
  `parenttype` varchar(255) DEFAULT NULL,
  `idx` int(11) NOT NULL DEFAULT 0,
  `file_name` varchar(255) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `module` varchar(255) DEFAULT NULL,
  `attached_to_name` varchar(255) DEFAULT NULL,
  `file_size` int(11) NOT NULL DEFAULT 0,
  `attached_to_doctype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `creation` (`creation`),
  KEY `attached_to_name` (`attached_to_name`),
  KEY `attached_to_doctype` (`attached_to_doctype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile`
--

LOCK TABLES `tabFile` WRITE;
/*!40000 ALTER TABLE `tabFile` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabForm Tour`
--

DROP TABLE IF EXISTS `tabForm Tour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabForm Tour` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `view_name` varchar(140) DEFAULT NULL,
  `workspace_name` varchar(140) DEFAULT NULL,
  `list_name` varchar(140) DEFAULT 'List',
  `report_name` varchar(140) DEFAULT NULL,
  `dashboard_name` varchar(140) DEFAULT NULL,
  `new_document_form` tinyint(4) NOT NULL DEFAULT 0,
  `page_name` varchar(140) DEFAULT NULL,
  `reference_doctype` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `ui_tour` tinyint(4) NOT NULL DEFAULT 0,
  `track_steps` tinyint(4) NOT NULL DEFAULT 0,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `save_on_complete` tinyint(4) NOT NULL DEFAULT 0,
  `first_document` tinyint(4) NOT NULL DEFAULT 0,
  `include_name_field` tinyint(4) NOT NULL DEFAULT 0,
  `page_route` text DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `title` (`title`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabForm Tour`
--

LOCK TABLES `tabForm Tour` WRITE;
/*!40000 ALTER TABLE `tabForm Tour` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabForm Tour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabForm Tour Step`
--

DROP TABLE IF EXISTS `tabForm Tour Step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabForm Tour Step` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `ui_tour` tinyint(4) NOT NULL DEFAULT 0,
  `is_table_field` tinyint(4) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `parent_fieldname` varchar(140) DEFAULT NULL,
  `fieldname` varchar(140) DEFAULT NULL,
  `element_selector` varchar(140) DEFAULT NULL,
  `parent_element_selector` varchar(140) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `ondemand_description` longtext DEFAULT NULL,
  `position` varchar(140) DEFAULT 'Bottom',
  `hide_buttons` tinyint(4) NOT NULL DEFAULT 0,
  `popover_element` tinyint(4) NOT NULL DEFAULT 0,
  `modal_trigger` tinyint(4) NOT NULL DEFAULT 0,
  `offset_x` int(11) NOT NULL DEFAULT 0,
  `offset_y` int(11) NOT NULL DEFAULT 0,
  `next_on_click` tinyint(4) NOT NULL DEFAULT 0,
  `label` varchar(140) DEFAULT NULL,
  `fieldtype` varchar(140) DEFAULT '0',
  `has_next_condition` tinyint(4) NOT NULL DEFAULT 0,
  `next_step_condition` longtext DEFAULT NULL,
  `next_form_tour` varchar(140) DEFAULT NULL,
  `child_doctype` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabForm Tour Step`
--

LOCK TABLES `tabForm Tour Step` WRITE;
/*!40000 ALTER TABLE `tabForm Tour Step` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabForm Tour Step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabHas Role`
--

DROP TABLE IF EXISTS `tabHas Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabHas Role` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `role` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabHas Role`
--

LOCK TABLES `tabHas Role` WRITE;
/*!40000 ALTER TABLE `tabHas Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabHas Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabLog Setting User`
--

DROP TABLE IF EXISTS `tabLog Setting User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabLog Setting User` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `user` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `user` (`user`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabLog Setting User`
--

LOCK TABLES `tabLog Setting User` WRITE;
/*!40000 ALTER TABLE `tabLog Setting User` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabLog Setting User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabModule Onboarding`
--

DROP TABLE IF EXISTS `tabModule Onboarding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabModule Onboarding` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `subtitle` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `success_message` varchar(140) DEFAULT NULL,
  `documentation_url` varchar(140) DEFAULT NULL,
  `is_complete` tinyint(4) NOT NULL DEFAULT 0,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabModule Onboarding`
--

LOCK TABLES `tabModule Onboarding` WRITE;
/*!40000 ALTER TABLE `tabModule Onboarding` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabModule Onboarding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabNotification`
--

DROP TABLE IF EXISTS `tabNotification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabNotification` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `enabled` tinyint(4) NOT NULL DEFAULT 1,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `channel` varchar(140) DEFAULT 'Email',
  `slack_webhook_url` varchar(140) DEFAULT NULL,
  `subject` varchar(140) DEFAULT NULL,
  `event` varchar(140) DEFAULT NULL,
  `document_type` varchar(140) DEFAULT NULL,
  `method` varchar(140) DEFAULT NULL,
  `date_changed` varchar(140) DEFAULT NULL,
  `days_in_advance` int(11) NOT NULL DEFAULT 0,
  `value_changed` varchar(140) DEFAULT NULL,
  `sender` varchar(140) DEFAULT NULL,
  `send_system_notification` tinyint(4) NOT NULL DEFAULT 0,
  `sender_email` varchar(140) DEFAULT NULL,
  `condition` longtext DEFAULT NULL,
  `set_property_after_alert` varchar(140) DEFAULT NULL,
  `property_value` varchar(140) DEFAULT NULL,
  `send_to_all_assignees` tinyint(4) NOT NULL DEFAULT 0,
  `message_type` varchar(140) DEFAULT 'Markdown',
  `message` longtext DEFAULT 'Add your message here',
  `attach_print` tinyint(4) NOT NULL DEFAULT 0,
  `print_format` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `event` (`event`),
  KEY `document_type` (`document_type`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabNotification`
--

LOCK TABLES `tabNotification` WRITE;
/*!40000 ALTER TABLE `tabNotification` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabNotification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabNumber Card`
--

DROP TABLE IF EXISTS `tabNumber Card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabNumber Card` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `type` varchar(140) DEFAULT NULL,
  `report_name` varchar(140) DEFAULT NULL,
  `method` varchar(140) DEFAULT NULL,
  `function` varchar(140) DEFAULT NULL,
  `aggregate_function_based_on` varchar(140) DEFAULT NULL,
  `document_type` varchar(140) DEFAULT NULL,
  `parent_document_type` varchar(140) DEFAULT NULL,
  `report_field` varchar(140) DEFAULT NULL,
  `report_function` varchar(140) DEFAULT NULL,
  `is_public` tinyint(4) NOT NULL DEFAULT 0,
  `filters_config` longtext DEFAULT NULL,
  `show_percentage_stats` tinyint(4) NOT NULL DEFAULT 1,
  `stats_time_interval` varchar(140) DEFAULT 'Daily',
  `filters_json` longtext DEFAULT NULL,
  `dynamic_filters_json` longtext DEFAULT NULL,
  `color` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabNumber Card`
--

LOCK TABLES `tabNumber Card` WRITE;
/*!40000 ALTER TABLE `tabNumber Card` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabNumber Card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabOnboarding Permission`
--

DROP TABLE IF EXISTS `tabOnboarding Permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabOnboarding Permission` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `role` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabOnboarding Permission`
--

LOCK TABLES `tabOnboarding Permission` WRITE;
/*!40000 ALTER TABLE `tabOnboarding Permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabOnboarding Permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabOnboarding Step`
--

DROP TABLE IF EXISTS `tabOnboarding Step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabOnboarding Step` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `is_complete` tinyint(4) NOT NULL DEFAULT 0,
  `is_skipped` tinyint(4) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `intro_video_url` varchar(140) DEFAULT NULL,
  `action` varchar(140) DEFAULT NULL,
  `action_label` varchar(140) DEFAULT NULL,
  `reference_document` varchar(140) DEFAULT NULL,
  `show_full_form` tinyint(4) NOT NULL DEFAULT 0,
  `show_form_tour` tinyint(4) NOT NULL DEFAULT 0,
  `form_tour` varchar(140) DEFAULT NULL,
  `is_single` tinyint(4) NOT NULL DEFAULT 0,
  `reference_report` varchar(140) DEFAULT NULL,
  `report_reference_doctype` varchar(140) DEFAULT NULL,
  `report_type` varchar(140) DEFAULT NULL,
  `report_description` varchar(140) DEFAULT NULL,
  `path` varchar(140) DEFAULT NULL,
  `callback_title` varchar(140) DEFAULT NULL,
  `callback_message` text DEFAULT NULL,
  `validate_action` tinyint(4) NOT NULL DEFAULT 1,
  `field` varchar(140) DEFAULT NULL,
  `value_to_validate` varchar(140) DEFAULT NULL,
  `video_url` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabOnboarding Step`
--

LOCK TABLES `tabOnboarding Step` WRITE;
/*!40000 ALTER TABLE `tabOnboarding Step` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabOnboarding Step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabOnboarding Step Map`
--

DROP TABLE IF EXISTS `tabOnboarding Step Map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabOnboarding Step Map` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `step` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabOnboarding Step Map`
--

LOCK TABLES `tabOnboarding Step Map` WRITE;
/*!40000 ALTER TABLE `tabOnboarding Step Map` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabOnboarding Step Map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage`
--

DROP TABLE IF EXISTS `tabPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `system_page` tinyint(4) NOT NULL DEFAULT 0,
  `page_name` varchar(140) DEFAULT NULL,
  `title` varchar(140) DEFAULT NULL,
  `icon` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `restrict_to_domain` varchar(140) DEFAULT NULL,
  `standard` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `page_name` (`page_name`),
  KEY `standard` (`standard`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage`
--

LOCK TABLES `tabPage` WRITE;
/*!40000 ALTER TABLE `tabPage` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPatch Log`
--

DROP TABLE IF EXISTS `tabPatch Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPatch Log` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `patch` longtext DEFAULT NULL,
  `skipped` tinyint(4) NOT NULL DEFAULT 0,
  `traceback` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPatch Log`
--

LOCK TABLES `tabPatch Log` WRITE;
/*!40000 ALTER TABLE `tabPatch Log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPatch Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPortal Menu Item`
--

DROP TABLE IF EXISTS `tabPortal Menu Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPortal Menu Item` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT 0,
  `route` varchar(140) DEFAULT NULL,
  `reference_doctype` varchar(140) DEFAULT NULL,
  `role` varchar(140) DEFAULT NULL,
  `target` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPortal Menu Item`
--

LOCK TABLES `tabPortal Menu Item` WRITE;
/*!40000 ALTER TABLE `tabPortal Menu Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPortal Menu Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPrint Format`
--

DROP TABLE IF EXISTS `tabPrint Format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPrint Format` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `doc_type` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `default_print_language` varchar(140) DEFAULT NULL,
  `standard` varchar(140) DEFAULT 'No',
  `custom_format` tinyint(4) NOT NULL DEFAULT 0,
  `disabled` tinyint(4) NOT NULL DEFAULT 0,
  `print_format_type` varchar(140) DEFAULT 'Jinja',
  `raw_printing` tinyint(4) NOT NULL DEFAULT 0,
  `html` longtext DEFAULT NULL,
  `raw_commands` longtext DEFAULT NULL,
  `margin_top` decimal(21,9) NOT NULL DEFAULT 15.000000000,
  `margin_bottom` decimal(21,9) NOT NULL DEFAULT 15.000000000,
  `margin_left` decimal(21,9) NOT NULL DEFAULT 15.000000000,
  `margin_right` decimal(21,9) NOT NULL DEFAULT 15.000000000,
  `align_labels_right` tinyint(4) NOT NULL DEFAULT 0,
  `show_section_headings` tinyint(4) NOT NULL DEFAULT 0,
  `line_breaks` tinyint(4) NOT NULL DEFAULT 0,
  `absolute_value` tinyint(4) NOT NULL DEFAULT 0,
  `font_size` int(11) NOT NULL DEFAULT 14,
  `font` varchar(140) DEFAULT NULL,
  `page_number` varchar(140) DEFAULT 'Hide',
  `css` longtext DEFAULT NULL,
  `format_data` longtext DEFAULT NULL,
  `print_format_builder` tinyint(4) NOT NULL DEFAULT 0,
  `print_format_builder_beta` tinyint(4) NOT NULL DEFAULT 0,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `standard` (`standard`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPrint Format`
--

LOCK TABLES `tabPrint Format` WRITE;
/*!40000 ALTER TABLE `tabPrint Format` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPrint Format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPrint Style`
--

DROP TABLE IF EXISTS `tabPrint Style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPrint Style` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `print_style_name` varchar(140) DEFAULT NULL,
  `disabled` tinyint(4) NOT NULL DEFAULT 0,
  `standard` tinyint(4) NOT NULL DEFAULT 0,
  `css` longtext DEFAULT NULL,
  `preview` text DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `print_style_name` (`print_style_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPrint Style`
--

LOCK TABLES `tabPrint Style` WRITE;
/*!40000 ALTER TABLE `tabPrint Style` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPrint Style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabProperty Setter`
--

DROP TABLE IF EXISTS `tabProperty Setter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabProperty Setter` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `is_system_generated` tinyint(4) NOT NULL DEFAULT 0,
  `doctype_or_field` varchar(140) DEFAULT NULL,
  `doc_type` varchar(140) DEFAULT NULL,
  `field_name` varchar(140) DEFAULT NULL,
  `row_name` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `property` varchar(140) DEFAULT NULL,
  `property_type` varchar(140) DEFAULT NULL,
  `value` text DEFAULT NULL,
  `default_value` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `doc_type` (`doc_type`),
  KEY `field_name` (`field_name`),
  KEY `property` (`property`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabProperty Setter`
--

LOCK TABLES `tabProperty Setter` WRITE;
/*!40000 ALTER TABLE `tabProperty Setter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabProperty Setter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabReport`
--

DROP TABLE IF EXISTS `tabReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabReport` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `report_name` varchar(140) DEFAULT NULL,
  `ref_doctype` varchar(140) DEFAULT NULL,
  `reference_report` varchar(140) DEFAULT NULL,
  `is_standard` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `report_type` varchar(140) DEFAULT NULL,
  `letter_head` varchar(140) DEFAULT NULL,
  `add_total_row` tinyint(4) NOT NULL DEFAULT 0,
  `disabled` tinyint(4) NOT NULL DEFAULT 0,
  `prepared_report` tinyint(4) NOT NULL DEFAULT 0,
  `query` longtext DEFAULT NULL,
  `report_script` longtext DEFAULT NULL,
  `javascript` longtext DEFAULT NULL,
  `json` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `report_name` (`report_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabReport`
--

LOCK TABLES `tabReport` WRITE;
/*!40000 ALTER TABLE `tabReport` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabReport Filter`
--

DROP TABLE IF EXISTS `tabReport Filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabReport Filter` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `label` varchar(140) DEFAULT NULL,
  `fieldtype` varchar(140) DEFAULT NULL,
  `fieldname` varchar(140) DEFAULT NULL,
  `mandatory` tinyint(4) NOT NULL DEFAULT 0,
  `wildcard_filter` tinyint(4) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL,
  `default` text DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabReport Filter`
--

LOCK TABLES `tabReport Filter` WRITE;
/*!40000 ALTER TABLE `tabReport Filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabReport Filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabRole`
--

DROP TABLE IF EXISTS `tabRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabRole` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `role_name` varchar(140) DEFAULT NULL,
  `home_page` varchar(140) DEFAULT NULL,
  `restrict_to_domain` varchar(140) DEFAULT NULL,
  `disabled` tinyint(4) NOT NULL DEFAULT 0,
  `is_custom` tinyint(4) NOT NULL DEFAULT 0,
  `desk_access` tinyint(4) NOT NULL DEFAULT 1,
  `two_factor_auth` tinyint(4) NOT NULL DEFAULT 0,
  `search_bar` tinyint(4) NOT NULL DEFAULT 1,
  `notifications` tinyint(4) NOT NULL DEFAULT 1,
  `list_sidebar` tinyint(4) NOT NULL DEFAULT 1,
  `bulk_actions` tinyint(4) NOT NULL DEFAULT 1,
  `view_switcher` tinyint(4) NOT NULL DEFAULT 1,
  `form_sidebar` tinyint(4) NOT NULL DEFAULT 1,
  `timeline` tinyint(4) NOT NULL DEFAULT 1,
  `dashboard` tinyint(4) NOT NULL DEFAULT 1,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `role_name` (`role_name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabRole`
--

LOCK TABLES `tabRole` WRITE;
/*!40000 ALTER TABLE `tabRole` DISABLE KEYS */;
INSERT INTO `tabRole` VALUES ('Administrator','2024-08-17 15:55:55.505550','2024-08-17 15:55:55.505550','Administrator','Administrator',0,0,'Administrator',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('All','2024-08-17 15:55:55.490045','2024-08-17 15:55:55.490045','Administrator','Administrator',0,0,'All',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Dashboard Manager','2024-08-17 15:55:56.091080','2024-08-17 15:55:56.091080','Administrator','Administrator',0,0,'Dashboard Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Desk User','2024-08-17 15:55:55.474694','2024-08-17 15:55:55.474694','Administrator','Administrator',0,0,'Desk User',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Guest','2024-08-17 15:55:55.482332','2024-08-17 15:55:55.482332','Administrator','Administrator',0,0,'Guest',NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,NULL,NULL),('Report Manager','2024-08-17 15:55:57.084345','2024-08-17 15:55:57.084345','Administrator','Administrator',0,0,'Report Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Script Manager','2024-08-17 15:55:57.697522','2024-08-17 15:55:57.697522','Administrator','Administrator',0,0,'Script Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('System Manager','2024-08-17 15:55:55.497882','2024-08-17 15:55:55.497882','Administrator','Administrator',0,0,'System Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Website Manager','2024-08-17 15:55:55.839257','2024-08-17 15:55:55.839257','Administrator','Administrator',0,0,'Website Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('Workspace Manager','2024-08-17 15:55:56.934603','2024-08-17 15:55:56.934603','Administrator','Administrator',0,0,'Workspace Manager',NULL,NULL,0,0,1,0,1,1,1,1,1,1,1,1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSeries`
--

DROP TABLE IF EXISTS `tabSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSeries` (
  `name` varchar(100) NOT NULL,
  `current` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSeries`
--

LOCK TABLES `tabSeries` WRITE;
/*!40000 ALTER TABLE `tabSeries` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabServer Script`
--

DROP TABLE IF EXISTS `tabServer Script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabServer Script` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `script_type` varchar(140) DEFAULT NULL,
  `reference_doctype` varchar(140) DEFAULT NULL,
  `event_frequency` varchar(140) DEFAULT NULL,
  `cron_format` varchar(140) DEFAULT NULL,
  `doctype_event` varchar(140) DEFAULT NULL,
  `api_method` varchar(140) DEFAULT NULL,
  `allow_guest` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `disabled` tinyint(4) NOT NULL DEFAULT 0,
  `script` longtext DEFAULT NULL,
  `enable_rate_limit` tinyint(4) NOT NULL DEFAULT 0,
  `rate_limit_count` int(11) NOT NULL DEFAULT 5,
  `rate_limit_seconds` int(11) NOT NULL DEFAULT 86400,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `reference_doctype` (`reference_doctype`),
  KEY `module` (`module`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabServer Script`
--

LOCK TABLES `tabServer Script` WRITE;
/*!40000 ALTER TABLE `tabServer Script` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabServer Script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSessions`
--

DROP TABLE IF EXISTS `tabSessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSessions` (
  `user` varchar(255) DEFAULT NULL,
  `sid` varchar(255) DEFAULT NULL,
  `sessiondata` longtext DEFAULT NULL,
  `ipaddress` varchar(16) DEFAULT NULL,
  `lastupdate` datetime(6) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSessions`
--

LOCK TABLES `tabSessions` WRITE;
/*!40000 ALTER TABLE `tabSessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSingles`
--

DROP TABLE IF EXISTS `tabSingles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSingles` (
  `doctype` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `value` longtext DEFAULT NULL,
  KEY `singles_doctype_field_index` (`doctype`,`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSingles`
--

LOCK TABLES `tabSingles` WRITE;
/*!40000 ALTER TABLE `tabSingles` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSingles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabTranslation`
--

DROP TABLE IF EXISTS `tabTranslation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabTranslation` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `contributed` tinyint(4) NOT NULL DEFAULT 0,
  `language` varchar(140) DEFAULT NULL,
  `source_text` longtext DEFAULT NULL,
  `context` varchar(140) DEFAULT NULL,
  `translated_text` longtext DEFAULT NULL,
  `contribution_status` varchar(140) DEFAULT NULL,
  `contribution_docname` varchar(140) DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `language` (`language`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabTranslation`
--

LOCK TABLES `tabTranslation` WRITE;
/*!40000 ALTER TABLE `tabTranslation` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabTranslation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Form`
--

DROP TABLE IF EXISTS `tabWeb Form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Form` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `route` varchar(140) DEFAULT NULL,
  `published` tinyint(4) NOT NULL DEFAULT 0,
  `doc_type` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `is_standard` tinyint(4) NOT NULL DEFAULT 0,
  `introduction_text` longtext DEFAULT NULL,
  `login_required` tinyint(4) NOT NULL DEFAULT 0,
  `allow_multiple` tinyint(4) NOT NULL DEFAULT 0,
  `allow_edit` tinyint(4) NOT NULL DEFAULT 0,
  `allow_delete` tinyint(4) NOT NULL DEFAULT 0,
  `anonymous` tinyint(4) NOT NULL DEFAULT 0,
  `apply_document_permissions` tinyint(4) NOT NULL DEFAULT 0,
  `allow_print` tinyint(4) NOT NULL DEFAULT 0,
  `print_format` varchar(140) DEFAULT NULL,
  `allow_comments` tinyint(4) NOT NULL DEFAULT 0,
  `show_attachments` tinyint(4) NOT NULL DEFAULT 0,
  `allow_incomplete` tinyint(4) NOT NULL DEFAULT 0,
  `max_attachment_size` int(11) NOT NULL DEFAULT 0,
  `condition_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`condition_json`)),
  `show_list` tinyint(4) NOT NULL DEFAULT 0,
  `list_title` varchar(140) DEFAULT NULL,
  `show_sidebar` tinyint(4) NOT NULL DEFAULT 0,
  `website_sidebar` varchar(140) DEFAULT NULL,
  `button_label` varchar(140) DEFAULT 'Save',
  `banner_image` text DEFAULT NULL,
  `breadcrumbs` longtext DEFAULT NULL,
  `success_title` varchar(140) DEFAULT NULL,
  `success_url` varchar(140) DEFAULT NULL,
  `success_message` text DEFAULT NULL,
  `meta_title` varchar(140) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_image` text DEFAULT NULL,
  `client_script` longtext DEFAULT NULL,
  `custom_css` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `route` (`route`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Form`
--

LOCK TABLES `tabWeb Form` WRITE;
/*!40000 ALTER TABLE `tabWeb Form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Form Field`
--

DROP TABLE IF EXISTS `tabWeb Form Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Form Field` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `fieldname` varchar(140) DEFAULT NULL,
  `fieldtype` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `allow_read_on_all_link_options` tinyint(4) NOT NULL DEFAULT 0,
  `reqd` tinyint(4) NOT NULL DEFAULT 0,
  `read_only` tinyint(4) NOT NULL DEFAULT 0,
  `show_in_filter` tinyint(4) NOT NULL DEFAULT 0,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `options` text DEFAULT NULL,
  `max_length` int(11) NOT NULL DEFAULT 0,
  `max_value` int(11) NOT NULL DEFAULT 0,
  `precision` varchar(140) DEFAULT NULL,
  `depends_on` longtext DEFAULT NULL,
  `mandatory_depends_on` longtext DEFAULT NULL,
  `read_only_depends_on` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `default` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Form Field`
--

LOCK TABLES `tabWeb Form Field` WRITE;
/*!40000 ALTER TABLE `tabWeb Form Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Form Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Page`
--

DROP TABLE IF EXISTS `tabWeb Page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Page` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `title` varchar(140) DEFAULT NULL,
  `route` varchar(140) DEFAULT NULL,
  `dynamic_route` tinyint(4) NOT NULL DEFAULT 0,
  `published` tinyint(4) NOT NULL DEFAULT 1,
  `module` varchar(140) DEFAULT NULL,
  `content_type` varchar(140) DEFAULT 'Page Builder',
  `slideshow` varchar(140) DEFAULT NULL,
  `dynamic_template` tinyint(4) NOT NULL DEFAULT 0,
  `main_section` longtext DEFAULT NULL,
  `main_section_md` longtext DEFAULT NULL,
  `main_section_html` longtext DEFAULT NULL,
  `context_script` longtext DEFAULT NULL,
  `javascript` longtext DEFAULT NULL,
  `insert_style` tinyint(4) NOT NULL DEFAULT 0,
  `text_align` varchar(140) DEFAULT NULL,
  `css` longtext DEFAULT NULL,
  `full_width` tinyint(4) NOT NULL DEFAULT 1,
  `show_title` tinyint(4) NOT NULL DEFAULT 0,
  `start_date` datetime(6) DEFAULT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `meta_title` varchar(140) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `meta_image` text DEFAULT NULL,
  `show_sidebar` tinyint(4) NOT NULL DEFAULT 0,
  `website_sidebar` varchar(140) DEFAULT NULL,
  `enable_comments` tinyint(4) NOT NULL DEFAULT 0,
  `header` longtext DEFAULT NULL,
  `breadcrumbs` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `route` (`route`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Page`
--

LOCK TABLES `tabWeb Page` WRITE;
/*!40000 ALTER TABLE `tabWeb Page` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Template`
--

DROP TABLE IF EXISTS `tabWeb Template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Template` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `type` varchar(140) DEFAULT 'Section',
  `standard` tinyint(4) NOT NULL DEFAULT 0,
  `module` varchar(140) DEFAULT NULL,
  `template` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Template`
--

LOCK TABLES `tabWeb Template` WRITE;
/*!40000 ALTER TABLE `tabWeb Template` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWebsite Theme`
--

DROP TABLE IF EXISTS `tabWebsite Theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWebsite Theme` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `theme` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT 'Website',
  `custom` tinyint(4) NOT NULL DEFAULT 1,
  `google_font` varchar(140) DEFAULT NULL,
  `font_size` varchar(140) DEFAULT NULL,
  `font_properties` varchar(140) DEFAULT 'wght@300;400;500;600;700;800',
  `button_rounded_corners` tinyint(4) NOT NULL DEFAULT 1,
  `button_shadows` tinyint(4) NOT NULL DEFAULT 0,
  `button_gradients` tinyint(4) NOT NULL DEFAULT 0,
  `primary_color` varchar(140) DEFAULT NULL,
  `text_color` varchar(140) DEFAULT NULL,
  `light_color` varchar(140) DEFAULT NULL,
  `dark_color` varchar(140) DEFAULT NULL,
  `background_color` varchar(140) DEFAULT NULL,
  `custom_overrides` longtext DEFAULT NULL,
  `custom_scss` longtext DEFAULT NULL,
  `theme_scss` longtext DEFAULT NULL,
  `theme_url` varchar(140) DEFAULT NULL,
  `js` longtext DEFAULT NULL,
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `theme` (`theme`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWebsite Theme`
--

LOCK TABLES `tabWebsite Theme` WRITE;
/*!40000 ALTER TABLE `tabWebsite Theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWebsite Theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace`
--

DROP TABLE IF EXISTS `tabWorkspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `label` varchar(140) DEFAULT NULL,
  `title` varchar(140) DEFAULT NULL,
  `sequence_id` decimal(21,9) NOT NULL DEFAULT 0.000000000,
  `for_user` varchar(140) DEFAULT NULL,
  `parent_page` varchar(140) DEFAULT NULL,
  `module` varchar(140) DEFAULT NULL,
  `icon` varchar(140) DEFAULT NULL,
  `indicator_color` varchar(140) DEFAULT NULL,
  `restrict_to_domain` varchar(140) DEFAULT NULL,
  `hide_custom` tinyint(4) NOT NULL DEFAULT 0,
  `public` tinyint(4) NOT NULL DEFAULT 0,
  `is_hidden` tinyint(4) NOT NULL DEFAULT 0,
  `content` longtext DEFAULT '[]',
  `_user_tags` text DEFAULT NULL,
  `_comments` text DEFAULT NULL,
  `_assign` text DEFAULT NULL,
  `_liked_by` text DEFAULT NULL,
  PRIMARY KEY (`name`),
  UNIQUE KEY `label` (`label`),
  KEY `restrict_to_domain` (`restrict_to_domain`),
  KEY `public` (`public`),
  KEY `creation` (`creation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace`
--

LOCK TABLES `tabWorkspace` WRITE;
/*!40000 ALTER TABLE `tabWorkspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Chart`
--

DROP TABLE IF EXISTS `tabWorkspace Chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Chart` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `chart_name` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Chart`
--

LOCK TABLES `tabWorkspace Chart` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Chart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Custom Block`
--

DROP TABLE IF EXISTS `tabWorkspace Custom Block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Custom Block` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `custom_block_name` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Custom Block`
--

LOCK TABLES `tabWorkspace Custom Block` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Custom Block` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Custom Block` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Link`
--

DROP TABLE IF EXISTS `tabWorkspace Link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Link` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `type` varchar(140) DEFAULT 'Link',
  `label` varchar(140) DEFAULT NULL,
  `icon` varchar(140) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT 0,
  `link_type` varchar(140) DEFAULT NULL,
  `link_to` varchar(140) DEFAULT NULL,
  `dependencies` varchar(140) DEFAULT NULL,
  `only_for` varchar(140) DEFAULT NULL,
  `onboard` tinyint(4) NOT NULL DEFAULT 0,
  `is_query_report` tinyint(4) NOT NULL DEFAULT 0,
  `link_count` int(11) NOT NULL DEFAULT 0,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Link`
--

LOCK TABLES `tabWorkspace Link` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Number Card`
--

DROP TABLE IF EXISTS `tabWorkspace Number Card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Number Card` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `number_card_name` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Number Card`
--

LOCK TABLES `tabWorkspace Number Card` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Number Card` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Number Card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Quick List`
--

DROP TABLE IF EXISTS `tabWorkspace Quick List`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Quick List` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `document_type` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `quick_list_filter` longtext DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Quick List`
--

LOCK TABLES `tabWorkspace Quick List` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Quick List` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Quick List` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkspace Shortcut`
--

DROP TABLE IF EXISTS `tabWorkspace Shortcut`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkspace Shortcut` (
  `name` varchar(140) NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(140) DEFAULT NULL,
  `owner` varchar(140) DEFAULT NULL,
  `docstatus` tinyint(4) NOT NULL DEFAULT 0,
  `idx` int(11) NOT NULL DEFAULT 0,
  `type` varchar(140) DEFAULT NULL,
  `link_to` varchar(140) DEFAULT NULL,
  `url` varchar(140) DEFAULT NULL,
  `doc_view` varchar(140) DEFAULT NULL,
  `kanban_board` varchar(140) DEFAULT NULL,
  `label` varchar(140) DEFAULT NULL,
  `icon` varchar(140) DEFAULT NULL,
  `restrict_to_domain` varchar(140) DEFAULT NULL,
  `stats_filter` longtext DEFAULT NULL,
  `color` varchar(140) DEFAULT NULL,
  `format` varchar(140) DEFAULT NULL,
  `parent` varchar(140) DEFAULT NULL,
  `parentfield` varchar(140) DEFAULT NULL,
  `parenttype` varchar(140) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkspace Shortcut`
--

LOCK TABLES `tabWorkspace Shortcut` WRITE;
/*!40000 ALTER TABLE `tabWorkspace Shortcut` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkspace Shortcut` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-17 16:01:04
